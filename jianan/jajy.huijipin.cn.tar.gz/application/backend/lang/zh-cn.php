<?php
/**
 * Created by PhpStorm.
 * User: dxf
 * Date: 2017/12/19
 * Time: 13:30
 * info: 中文简体语言包
 */

return [
    'name' => '管理后台',
];
