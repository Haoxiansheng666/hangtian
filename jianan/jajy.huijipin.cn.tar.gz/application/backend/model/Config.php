<?php
namespace app\backend\model;
use think\Model;
use think\Db;
class Config extends Model
{   
	

}
 

