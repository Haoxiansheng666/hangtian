<?php
namespace app\backend\model;
use think\Model;
class AdminPwdcount extends Model
{   
    protected $update = array(
       'updated_t',
    );
}
 
