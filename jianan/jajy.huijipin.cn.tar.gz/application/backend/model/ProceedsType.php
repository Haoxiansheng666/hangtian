<?php
namespace app\backend\model;
use think\Model;
use think\Request;
use think\Db;
class ProceedsType extends BaseModel
{   

}
 
