<?php
namespace app\backend\model;
use think\Model;
class CustomerSource extends BaseModel
{   

    protected $tableName = 'customer_source';
    protected $autoWriteTimestamp = true;
    protected $createTime = 'create_time';
    protected $updateTime = false;


    
     
}
 
