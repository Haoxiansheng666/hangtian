<?php
namespace app\backend\model;
use think\Model;
class CompanyCustomerBatch extends Model
{
    // 是否需要自动写入时间戳 如果设置为字符串 则表示时间字段的类型
    protected $autoWriteTimestamp = true;
    // 创建时间字段
    protected $createTime = 'create_time';
    protected $updateTime = false;

    protected $append = [
        'pay_status_text',
        'pay_end_time_text',
        'create_time_text'
    ];

    public function getStatusArray(){
        return [
            '0' => '未缴费',
            '1' => '未结清',
            '2' => '已结清',
        ];
    }

    public function getPayStatusTextAttr($value,$data){
        $status = $this->getStatusArray();
        return !empty($value) ? (!empty($status[$value]) ? $status[$value] : '未知') : (!empty($status[$data['pay_status']]) ? $status[$data['pay_status']] : '未知');
    }

    public function getCreateTimeTextAttr($value,$data){
        return !empty($value) ? date('Y-m-d H:i:s',$value) : (!empty($data['create_time']) ? date('Y-m-d H:i:s',$data['create_time']) : "时间格式错误");
    }

    public function getPayEndTimeTextAttr($value,$data){
        return !empty($value) ? date('Y-m-d H:i:s',$value) : (!empty($data['pay_end_time']) ? date('Y-m-d H:i:s',$data['pay_end_time']) : "时间格式错误");
    }

    public function customer(){
        return $this->hasOne('Customer','id','customer_id');
    }
}
 
