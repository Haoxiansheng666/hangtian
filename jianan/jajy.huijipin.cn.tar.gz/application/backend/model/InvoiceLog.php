<?php
namespace app\backend\model;
use think\Model;
use think\Request;
use think\Db;
class InvoiceLog extends BaseModel
{
    protected $autoWriteTimestamp = true;
    protected $createTime = 'create_time';

    protected $append = [
        'status_text',
        'create_time_text'
    ];

    public function getStatusTextAttr($value,$data){
        $status = [
            '未审核',
            '审核通过',
            '审核未通过',
        ];
        return !empty($status[$data['status']]) ? $status[$data['status']] : '审核状态错误';
    }

    public function getCreateTimeTextAttr($value,$data){
        return !empty($data['create_time']) ? date('Y-m-d H:i:s',$data['create_time']) : '';
    }
}
 
