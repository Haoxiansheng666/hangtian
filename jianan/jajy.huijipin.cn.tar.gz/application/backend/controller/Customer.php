<?php
namespace app\backend\controller;
use app\backend\model\AuthGroup;
use app\backend\model\CompanyCustomerBatch;
use app\backend\model\CustomerTransfer;
use app\backend\model\PayLog;
use app\backend\model\ProceedsType;
use app\backend\model\ProfessionCate;
use Exception;
use think\Controller;
use think\Db;
use think\Config;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;
use think\Model;
use think\Request;
use app\backend\model\CustomerCate;
use app\backend\model\CustomerFrom;
use app\backend\model\CustomerRecord;
use app\backend\model\Customer as C;
use app\backend\logic\CustomerLogic;
use app\backend\model\AdminUser;
class Customer  extends Common
{   
    protected $tableName = 'customer_cate';
    protected $tableName1 = 'customer';

    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $cate_list=CustomerCate::getAll(['status'=>1]);
        $this->assign('cate_list',$cate_list);
        // 判断业务权限
        $admin = $this->ausess();
        $this->assign('admin_info',$admin);
        $auth_sf = 0;
        $group = AuthGroup::get($admin['group_id']);
        if ($group['pid'] == 0 && $group['department_id'] == 0){
            $aulist=AdminUser::all();
            $auth_sf = 1;
        }else if ($group['pid'] == 0 && $group['department_id'] == 7){
            $aulist = AdminUser::all(['campus_id' => $admin['campus_id']]);
            $auth_sf = 2;
        }else{
            $top_group = AuthGroup::get($group['pid']);
            if ($top_group['pid'] == 0){
                $aulist = AdminUser::all(['pid' => $admin['auid'],'campus_id' => $admin['campus_id']]);
                $auth_sf = 3;
            }else{
                $aulist = [];
                $auth_sf = 4;
            }
        }
        $this->assign('aulist',$aulist);
        $this->assign('auth_sf',$auth_sf);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        // 支付方式
        $proceeds_type = ProceedsType::all();
        $this->assign('proceeds_type',$proceeds_type);
    }

    /**
     * 客户列表
     * @access public
     * @return mixed
     */
    public function index(){
        return  $this->fetch();
    }

    /**
     * 客户列表数据的获取
     * @access public
     * @return void [json]
     */
    public function getData(){
        $model=new C;
        $param=input('param.');
        $where=CustomerLogic::selectParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
//        var_dump($where);die;
        $rs=$model->get_join_list($param,$where);
        layuiReturn($this->errCode('OK'), '获取成功', $rs['count'], $rs['list']);
    }

    /**
     * 客户数据的删除
     * @access public
     * @return void [json]
     */
    public function delete(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $ress=$this->del($this->tableName1);
          return $ress;
       }
    }

    /**
     * 客户添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function add(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new C;
          $ress=$this->addAction($model);
      }else{
          $param=input('param.');
          $catelist=CustomerCate::getAll(['status'=>1]);
          $fromlist=CustomerFrom::getAll(['status'=>1]);
          $source_list = \app\backend\model\CustomerSource::all();
          if(!empty($param['id'])){
              $ress= C::get($param['id']);
              if (!empty($ress['id'])){
                  $ress['customer_cate_id'] = $ress['cate_id'];
                  $ress['customer_id'] = $ress['id'];
                  $ress['pid'] = 0;
                  // 查询学员工种上级栏目ID
                  $profession = \app\backend\model\Profession::get($ress['profession_id']);
                  $cate_id = ProfessionCate::get($profession['cate_id']);
                  $ress['cate_id'] = $cate_id['id'];
                  $ress['pid'] = $profession['pid'];
              }
          }else{
              $ress=[
                  'cate_id'=>'',
                  'customer_cate_id'=>'',
                  'customer_source_name'=>'',
                  'from'=>''
              ];
          }
          $data=['ress'=>$ress,'fromlist'=>$fromlist,'catelist'=>$catelist,'source_list' => $source_list];
          $this->assign('data',$data);
          return  $this->fetch();
      }
    }

    /**
     * 客户详情
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     */
    public function detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= C::get($param['id']);
            if (!empty($ress['profession_id'])){
                $ress['profession_info'] = \app\backend\model\Profession::get($ress['profession_id']);
                $ress['profession_top_info'] = \app\backend\model\Profession::get($ress['profession_info']['pid']);
                $ress['profession_cate_info'] = ProfessionCate::get($ress['profession_info']['cate_id']);
            }
            $catelist=CustomerCate::getAll(['status'=>1]);
            $record= CustomerRecord::getAll(['customer_id'=>$param['id']]);
        }else{
            $this->error('页面出错了！');
        }
        $data=['record'=>$record,'ress'=>$ress,'param'=>$param,'catelist'=>$catelist];
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 企业客户缴费
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     */
    public function pay_money(){
        $param=input('param.');
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            if (empty($param['batch_number'])){
                $this->error('批次号不能为空');
            }
            $pay_log_data = [
                'batch_number' => $param['batch_number'],
                'pay_price' => $param['pay_price'],
                'pay_way' => $param['pay_way'],
                'pay_site' => $param['pay_site'],
                'proceeds_type' => $param['proceeds_type'],
                'pay_proof' => $param['pay_proof'],
                'remark' => $param['mark'],
                'create_time' => time(),
            ];
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $pay_log_data['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $pay_log_data['campus_id'] = 1;
            }
            (new PayLog())->save($pay_log_data);
            $this->success('已提交财务审核');
        }
        if(isset($param['id']) && !empty($param['id'])){
            $ress= C::get($param['id']);
            $batch_number = CompanyCustomerBatch::all([
                'customer_id' => $param['id']
            ]);
        }else{
            $this->error('页面出错了！');
        }
        $data=['ress'=>$ress,'param'=>$param];
        $this->assign([
            'batch_number' => $batch_number
        ]);
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 放弃客户
     * @throws DbException
     */
    public function abandon(){
        $id = $this->request->param('id');
        $customer = C::get($id);
        $customer->auid = null;
        $customer->group_id = null;
        $customer->save();
        $this->success('客户已转入公海库');
    }

    /**
     * 转移客户
     * @throws DbException
     */
    public function make_over(){
        $id = $this->request->param('id');
        $auid = $this->request->param('auid');
        $transfer_cause = $this->request->param('transfer_cause');
        if (empty($id) || empty($auid)){
            $this->error('参数错误');
        }
        $data = [
            'customer_id' => $id,
            'old_admin_id' => $this->ausess()['auid'],
            'admin_id' => $auid,
            'transfer_cause' => $transfer_cause
        ];
        $admin = AdminUser::get($auid);
        if ($admin['department_id'] != $this->ausess()['department_id']){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
            $data['audit_time'] = time();
            $customer = C::get($id);
            $customer->save([
                'auid' => $admin['id'],
                'group_id' => $admin['group_id']
            ]);
        }
        (new CustomerTransfer())->save($data);
        $this->success('客户转移申请已提交');
    }

    /**
     * 客户回访记录的添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function add_record(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new CustomerRecord;
          $param = $this->request->param();
          $customer = C::get($param['customer_id']);
          if (!empty($param['contents'])){
              $data = [
                  'customer_id' => $customer['id'],
                  'auid' => $customer['auid'],
                  'group_id' => $customer['group_id'],
                  'contents' => $param['contents'],
                  'create_time' => time(),
              ];
              $model->save($data);
          }
          // 修改客户状态
          $customer_data = [];
          if (!empty($param['warn_time'])){
              $customer_data['next_contact_time'] = strtotime($param['warn_time']);
              $customer_data['end_time'] = time();
              $customer_data['follow_status'] = 1;
          }else{
              $customer_data['next_contact_time'] = '';
              $customer_data['end_time'] = time();
              $customer_data['follow_status'] = 2;
          }
          $result = $customer->save($customer_data);
          if ($result){
              ajaxReturn(1, '跟进记录保存成功');
          }else{
              ajaxReturn($this->errCode('SQLError'), '页面出错了');
          }
      }else{
          $param=input('param.');
          if(isset($param['id']) && !empty($param['id'])){
              $ress= C::get($param['id']);
              $catelist=CustomerCate::getAll(['status'=>1]);
          }else{
             $this->error('页面出错了！');
          }
          $data=['id'=>$param['id'],'catelist'=>$catelist,'ress'=>$ress];
          $this->assign('data',$data);
          return  $this->fetch();
      }
    }

    /**
     * 客户数据下载
     * @access public
     * @return void [type]
     */
    public function down(){
      $model=new C;
      $param=input('param.');
      $where=CustomerLogic::selectParam($param,$this->ausess());
      $data=$model->get_down_list($param,$where);
      $excel_name='客户信息_'.date('YmdHis');
      CustomerLogic::down($data,$excel_name);
    }

    /**
     * 客户数据导入的模板下载
     * @access public
     * @return void [type]
     */
    public function muban(){
      $rr=CustomerLogic::muban();
      $excel_name='客户信息导入模板'; 
      CustomerLogic::down($rr,$excel_name);
    }

    /**
     * 客户数据导入
     * @access public
     * @return mixed|void
     * @throws Exception
     * @since dxf
     */
    public function leading(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $param=input('param.');
          $param['fileurl'] = ROOT_PATH.'public/'.$param['fileurl'];
          $rss=CustomerLogic::uploadFile($param['fileurl'],$this->ausess());
          if($rss['status']==1){
            $model=new C;
            $re=$model->saveAll($rss['data']);
            if($re){
                $this->success('数据导入成功');
            }else{
                $this->error('数据导入失败了');
            }
          }else{
              ajaxReturn($this->errCode('SQLError'), $rss['msg']);
          }
      }else{
          return  $this->fetch();
      }
    }

    /**
     * 下次联系时间
     */
    public function nextTime(){
        $param = $this->request->param();
        $ids =  $param['ids'] ? $param['ids'] : false;
        $next_time = $this->request->param('next_time');

        if (empty($ids)){
            $this->error('请选择数据');
        }
        if (empty($next_time)){
            $this->error('请选择正确时间');
        }

        $data = [
            'next_contact_time' => strtotime($next_time),
            'follow_status' => 1
        ];

        $result = (new C())->where('id','in',$ids)->update($data);
        if ($result){
            $this->success('下次联系时间设置成功');
        }
    }

    /**
     * 跟进
     * @throws \think\Exception
     * @throws DbException
     */
    public function follow(){
        $id = $this->request->param('id');
        $customer = (new C())->with('admin')->where('id',$id)->find();
        $customer_record = (new CustomerRecord())->where(['customer_id' => $id])->order('id DESC')->select();
        $this->assign([
            'customer' => $customer,
            'customer_record' => $customer_record
        ]);
        return $this->fetch();
    }

    /**
     * 报名缴费
     * @return mixed
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function pay(){
        $id = $this->request->param('id');
        $customer = (new C())->with('admin')->where('id',$id)->find();
        $customer['customer_id'] = $customer['id'];
        if (!empty($customer['profession_id'])){
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $customer['cate_id'] = $profession['cate_id'];
            $customer['pid'] = $profession['pid'];
        }

        unset($customer['id']);
        $admin = AdminUser::all();
        $this->assign([
            'admin' => $admin,
            'data' => $customer
        ]);
        return $this->fetch('pay_student/add');
    }

    /** 
     * 数据提交之前的操作
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [array] 
     */
    protected function before_add($data){
      if(empty($data['warn_time'])){
        unset($data['warn_time']);
      }
      // 增加校区字段
      if (!empty($this->campus_id)){
          $data['campus_id'] = $this->campus_id;
      }else{
          $data['campus_id'] = 1;
      }
      if (!empty($data['from']) && $data['from'] == 2 && empty($data['company'])){
          $this->error('请输入单位名称');
      }
      return $data;
    }
    /** 
     * 数据提交之后的操作
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [] 
     */
    protected function after_add($data){
        //更新客户表中的状态和下次提醒时间
        if(!empty($data['customer_id']) && !empty($data['cate_id'])){
          $model=new C;
          $updata['id']=$data['customer_id'];
          $updata['cate_id']=$data['cate_id'];
          $updata['warn_time']=strtotime($data['warn_time']);
          $ress=$model->update_data($updata);
        }
    }
    /** 
     * 数据提交之后写入数据库
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [] 
     */
    protected function write_log($data){
      if(!empty($data['customer_id'])){
        $contents="添加回访数据！";
      }elseif(!empty($data['cate_id'])){
        $contents="添加 / 修改了客户数据，名称：$data[name]";
      }else{
        $contents="添加 / 修改了客户分类/来源数据，名称：$data[name]";
      }
      $this->writelog($contents);
      
    }
    /** 
     * 数据删除之后的操作
     * @access public 
     * @param  array  $data  数据
     * @since dxf 
     * @return [] 
     */
    protected function after_del($data){
      if(!empty($data['cate_id'])){
         $contents="删除了客户数据，名称：$data[name]";
      }else{
         $contents="删除了客户分类/来源数据：$data[name]";
      }
      $this->writelog($contents);
    }

    /**
     * 客户转让记录
     * @return mixed
     */
    public function transfer_index(){
        return $this->fetch();
    }

    /**
     * 获取客户转让记录数据
     * @throws DbException
     */
    public function getTransferData(){
        $param=input('param.');
        $cus_where=CustomerLogic::selectParam($param,$this->ausess());
        $auid = $cus_where['auid'];
        unset($cus_where['auid']);
        if (!empty($cus_where)){
            $customer_ids = (new C())
                ->where($cus_where)
                ->column('id');
        }
        $where = [];
        // 客户信息筛选
        if (!empty($customer_ids)){
            $where['customer_id'] = ['in',$customer_ids];
        }
        $list = (new CustomerTransfer())
            ->with('oldAdmin,admins,customer')
            ->where($where);
        // 业务员筛选
        $list = $list
            ->whereOr(
                [
                    'old_admin_id' => $auid,
                    'admin_id' => $auid
                ]
            )
            ->paginate($this->request->param('limit'))
            ->each(function ($item){
                $data = $item->toArray();
                $item['customer_name'] = $data['customer']['name'];
                $item['customer_mobile'] = $data['customer']['mobile'];
                $item['old_admin_name'] = $data['old_admin']['real_name'];
                $item['admin_name'] = $data['admins']['real_name'];
            });

        layuiReturn($this->errCode('OK'), '获取成功' , $list->total() ,$list->items());
    }

    /**
     * 客户转让记录详情
     * @return mixed
     * @throws DbException
     */
    public function transfer_detail(){
        $id = $this->request->param('id');

        $transfer = (new CustomerTransfer())
            ->with('customer,admins,oldAdmin')
            ->where('id',$id)
            ->find();

        $this->assign([
            'info' => $transfer
        ]);

        return $this->fetch();
    }

    /**
     * 转让审核同意
     * @throws DbException
     */
    public function transfer_tongyi(){
        $id = $this->request->param('id');
        $transfer = CustomerTransfer::get($id);
        if (empty($transfer)){
            $this->error('访问错误');
        }
        $customer = C::get($transfer['customer_id']);
        if (empty($customer)){
            $this->error('访问错误');
        }
        $customer->save([
            'auid' => $transfer['admin_id'],
            'group_id' => $this->ausess()['group_id']
        ]);
        $transfer->save([
            'audit_id' => $this->ausess()['auid'],
            'audit_time' => time()
        ]);

        $this->success();
    }

    /**
     * 转让审核同意
     * @throws DbException
     */
    public function transfer_jujue(){
        $id = $this->request->param('id');
        $transfer = CustomerTransfer::get($id);
        if (empty($transfer)){
            $this->error('访问错误');
        }
        $customer = C::get($transfer['customer_id']);
        if (empty($customer)){
            $this->error('访问错误');
        }
        $customer->save([
            'auid' => $transfer['admin_id'],
            'group_id' => $this->ausess()['group_id']
        ]);
        $transfer->save([
            'audit_id' => $this->ausess()['auid'],
            'audit_time' => time()
        ]);

        $this->success();
    }



}
