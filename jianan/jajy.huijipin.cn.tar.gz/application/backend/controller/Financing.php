<?php
namespace app\backend\controller;
use app\backend\logic\FinancingLogic;
use app\backend\logic\ProfessionLogic;
use app\backend\model\AdminDeduct;
use app\backend\model\AdminUser;
use app\backend\model\CompanyCustomerBatch;
use app\backend\model\LabourCompanyRefund;
use app\backend\model\LabourCompanyReturned;
use app\backend\model\PayLog;
use app\backend\model\ProceedsType;
use app\backend\model\RefundLog;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;
use think\Model;
use think\Request;
use app\backend\model\ProfessionCate;
use app\backend\model\CustomerRecord;
use app\backend\model\PayStudent;
use app\backend\model\Profession as C;
class Financing extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        // 支付方式
        $proceeds_type = ProceedsType::all();
        $this->assign('proceeds_type',$proceeds_type);
        // 状态
        $status_list = (new PayStudent())->statusList();
        $this->assign('status_list',$status_list);
        // 企业名称
        $company_name = \app\backend\model\Customer::all([
            'from' => 2
        ]);
        $this->assign('company_name',$company_name);
    }

    /**
     * 客户列表
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     */
    public function statistics_index(){
        $aulist = AdminUser::all();
        $ware_id = $this->request->param('ware_id',1);
        $this->assign([
            'aulist' => $aulist,
            'ware_id' => $ware_id
        ]);
        return  $this->fetch();
    }

    /**
     * 企业客户财务统计数据
     * @throws DbException
     */
    public function getQyData(){
        $param = $this->request->param();
        $where = FinancingLogic::selectParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new CompanyCustomerBatch())
            ->with('customer.admin')
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list->items());
    }

    /**
     * 个人客户财务统计数据
     * @throws DbException
     */
    public function getGrData(){
        $param = $this->request->param();
        $where = FinancingLogic::selectGrParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new PayStudent())
            ->with('admin,authGroup,profession')
            ->where($where)
            ->where(['from' => 1])
            ->order('id DESC')
            ->paginate($param['limit']);
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list->items());
    }

    /**
     * 财务审核页面
     * @return mixed
     * @throws DbException
     */
    public function audit_index(){
        $where = [];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $aulist = AdminUser::all($where);
        $this->assign([
            'aulist' => $aulist,
            'ware_id' => $this->request->param('ware_id','1')
        ]);
        return $this->fetch();
    }

    /**
     * 财务审核数据
     * @throws DbException
     */
    public function getAuditData(){
        $param = $this->request->param();
        $where = FinancingLogic::selectAuditParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new PayLog())
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        $list_items = $list->items();
        foreach ($list_items as $k => $v){
            // 客户信息
            if (!empty($v['batch_number'])){
                $batch_number = $v['batch_number'];
                $customer = (new \app\backend\model\Customer())
                    ->with('admin')
                    ->where(function ($query) use ($batch_number){
                        $customer_id = (new CompanyCustomerBatch())
                            ->where('batch_number',$batch_number)
                            ->value('customer_id');
                        $query->where('id',$customer_id);
                    })
                    ->find();
            }else{
                $pay_student_id = $v['pay_student_id'];
                $customer = (new \app\backend\model\Customer())
                    ->with('admin')
                    ->where(function ($query) use ($pay_student_id){
                        $customer_id = (new PayStudent())
                            ->where('id',$pay_student_id)
                            ->value('customer_id');
                        $query->where('id',$customer_id);
                    })
                    ->find();
                $pay_student = (new PayStudent())->with('admin')->find(['id' => $pay_student_id]);
                $list_items[$k]['pay_student'] = $pay_student;
            }
            $list_items[$k]['customer'] = $customer;
            // 操作人
            if (!empty($v['operate_id'])){
                $operate = AdminUser::get($v['operate_id']);
            }else{
                $operate = [
                    'real_name' => '未审核'
                ];
            }
            $list_items[$k]['operate'] = $operate;
        }
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list_items);
    }

    /**
     * 获取下拉菜单数据
     * @throws DbException
     */
    public function selectData(){
        $cate_id = $this->request->param('cate_id');
        $data = C::all([
            'cate_id' => $cate_id,
            'pid' => 0
        ]);
        $this->success('','',$data);
    }

    /**
     * 获取下拉菜单数据
     * @throws DbException
     */
    public function selectSonData(){
        $cate_id = $this->request->param('cate_id');
        $data = C::all([
            'cate_id' => $cate_id,
            'pid' => ['<>','0']
        ]);
        $this->success('','',$data);
    }

    /**
     * 获取工种报名费用
     * @throws DbException
     */
    public function getPrice(){
        $profession_id = $this->request->param('profession_id');
        $data = C::get($profession_id);
        $this->success('','',$data);
    }

    /**
     * 客户详情
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            if ($param['ware_id'] == 1){
                $ress= (new CompanyCustomerBatch())
                    ->with('customer.admin')
                    ->where('id',$param['id'])
                    ->find();
            }else{
                $ress= (new PayStudent())
                    ->with('profession')
                    ->where('id',$param['id'])
                    ->find();
            }
            $where = [];
            if (!empty($ress['batch_number'])){
                $where['batch_number'] = $ress['batch_number'];
            }else{
                $where['pay_student_id'] = $ress['id'];
            }
            $pay_log = (new PayLog())
                ->where($where)
                ->select();
//            var_dump($ress->toArray());die;
        }else{
            $this->error('页面出错了！');
        }
        $href = url($this->request->param('refund'),[
            'ware_id' => $this->request->param('ware_id',1)
        ]);
        $data=['param'=>$param,'refund' => $href];
        $this->assign('data',$data);
        $this->assign('ress',$ress);
        $this->assign('pay_log',$pay_log);
        if ($param['ware_id'] == 2){
            return  $this->fetch();
        }else{
            return  $this->fetch('financing/company_detail');
        }
    }

    /**
     * 财务审核查看
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function audit_detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new PayLog())
                ->where('id',$param['id'])
                ->find();

            if (!empty($ress['batch_number'])){
                $price_relation = (new CompanyCustomerBatch())
                    ->where('batch_number',$ress['batch_number'])
                    ->find();
                $customer = (new \app\backend\model\Customer())
                    ->where('id',$price_relation['customer_id'])
                    ->find();
            }else {
                $price_relation = (new PayStudent())
                    ->with('profession,professionTop')
                    ->where('id',$ress['pay_student_id'])
                    ->find();
                $customer = (new \app\backend\model\Customer())
                    ->where('id',$price_relation['customer_id'])
                    ->find();
                if (empty($customer)){
                    $customer = $price_relation;
                }
            }
            $ress['price_relation'] = $price_relation;
            $ress['customer'] = $customer;
        }else{
            $this->error('页面出错了！');
        }
        $data=['ress'=>$ress, 'param'=>$param];
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 劳务派遣页面
     * @return mixed
     */
    public function labour_index(){
        $ware_id = $this->request->param('ware_id',1);
        $this->assign([
            'ware_id' => $ware_id
        ]);
        return  $this->fetch();
    }

    /**
     * 回款记录
     * @throws DbException
     */
    public function getReturnedData(){
        $param = $this->request->param();
        $where = [];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new LabourCompanyReturned())
            ->with('admin,company')
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list->items());
    }

    /**
     * 退款记录
     * @throws DbException
     */
    public function getRefundData(){
        $param = $this->request->param();
        $where = [];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new LabourCompanyRefund())
            ->with('admin,company')
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list->items());
    }

    /**
     * 客户数据下载
     * @access public
     * @return void [type]
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function down(){
      $param=input('param.');
      if (!empty($param) && $param['ware_id'] == 1){
          $param = $this->request->param();
          $where = FinancingLogic::selectParam($param,$this->ausess());
          $list = (new CompanyCustomerBatch())
              ->with('customer.admin')
              ->where($where)
              ->select();
          foreach ($list as $k => $v){
              $list[$k]['admin'] = $v['customer']['admin'];
          }
          $data=$this->get_down_company_list($list);
          $excel_name='企业客户财务统计_'.date('YmdHis');
      }else{
          $param = $this->request->param();
          $where = FinancingLogic::selectGrParam($param,$this->ausess());
          $list = (new PayStudent())
              ->with('admin,authGroup,profession')
              ->where($where)
              ->where(['from' => 1])
              ->select();
          foreach ($list as $k => $v){
              if (!empty($v['customer_id'])){
                  $customer = \app\backend\model\Customer::get($v['customer_id']);
                  $list[$k]['customer'] = $customer;
              }
          }
          $data = $this->get_down_list($list);
          $excel_name='个人客户财务统计_'.date('YmdHis');
      }
      FinancingLogic::down($data,$excel_name,$param['ware_id']);
    }

    /**
     * 导出企业客户数据
     * @param $list
     * @return mixed
     */
    public function get_down_company_list($list){
        $rs['0']['id']='编号';
        $rs['0']['batch_number']='公司批次号';
        $rs['0']['company_name']='公司名称';
        $rs['0']['name']='企业联系人';
        $rs['0']['mobile']='联系人电话';
        $rs['0']['total_price']='应缴费用';
        $rs['0']['pay_price']='实缴费用';
        $rs['0']['surplus_price']='余额';
        $rs['0']['admin']='业务员';
        $rs['0']['pay_status']='状态';
        $rs['0']['apply_num']='培训人员';
        $rs['0']['create_time']='创建时间';
        foreach ($list as $k => $v) {
            $k=$k+1;
            $rs[$k]['id']=$v['id'];
            $rs[$k]['batch_number']=$v['batch_number'];
            $rs[$k]['company_name'] = $v['customer']['company'];
            $rs[$k]['name'] = $v['customer']['name'];
            $rs[$k]['mobile'] = $v['customer']['mobile'];
            $rs[$k]['total_price'] = $v['total_price'];
            $rs[$k]['pay_price'] = $v['pay_price'];
            $rs[$k]['surplus_price'] = $v['pay_price'] - $v['total_price'];
            $rs[$k]['admin'] = $v['admin']['real_name'];
            $rs[$k]['pay_status'] = $v['pay_status_text'];
            $rs[$k]['apply_num'] = $v['apply_num'];
            $rs[$k]['create_time'] = $v['create_time_text'];
        }
        return $rs;
    }

    /**
     * 导出个人客户数据
     * @param $list
     * @return mixed
     */
    public function get_down_list($list){
        //数据赋值修改
        $rs['0']['id']='编号';
        $rs['0']['name']='客户名称';
        $rs['0']['mobile']='客户电话';
        $rs['0']['total_price']='应缴费用';
        $rs['0']['pay_price']='实缴费用';
        $rs['0']['surplus_price']='余额';
        $rs['0']['profession']='工种';
        $rs['0']['admin']='业务员';
        $rs['0']['status']='状态';
        $rs['0']['create_time']='创建时间';
        foreach ($list as $k => $v) {
            $v_array = $v->toArray();
            $k=$k+1;
            $rs[$k]['id']=$v_array['id'];
            $rs[$k]['name'] = !empty($v_array['customer']['name']) ? $v_array['customer']['name'] : $v_array['name'];
            $rs[$k]['mobile'] = !empty($v_array['customer']['mobile']) ? $v_array['customer']['mobile'] : $v_array['mobile'];
            $rs[$k]['total_price'] = $v_array['total_price'];
            $rs[$k]['pay_price'] = $v_array['pay_price'];
            $rs[$k]['surplus_price'] = $v_array['pay_price'] - $v_array['total_price'];
            $rs[$k]['profession'] = $v_array['profession']['name'];
            $rs[$k]['admin'] = $v_array['admin']['real_name'];
            $rs[$k]['status'] = $v_array['status_text'];
            $rs[$k]['create_time'] = $v_array['create_time_text'];
        }
        return $rs;
    }

    /**
     * 财务审核拒绝操作
     * @return mixed
     * @throws DbException
     */
    public function jujue(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            $pay_log = PayLog::get($param['id']);
            $update_data = [
                'feedback' => $param['feedback'],
                'status' => 2,
                'operate_id' => $this->ausess()['auid'],
                'operate_time' => time()
            ];
            $pay_log->save($update_data);
            // 修改客户状态
            $student = PayStudent::get($pay_log['pay_student_id']);
            if (!empty($student)){
                $student->feedback = $update_data['feedback'];
                $student->status = '-3';
                $student->save();
            }

            $this->success('审核操作完成');
        }
        $data = [
            'id' => $this->request->param('id')
        ];
        $this->assign('data',$data);
        return $this->fetch();
    }

    /**
     * 财务审核通过
     * @throws DbException
     * @throws \think\Exception
     */
    public function tongyi(){
        if(request()->isPost()){
            $param = $this->request->param();
            $pay_log = PayLog::get($param['id']);
            // 修改支付记录
            $update_data = [
                'status' => 1,
                'operate_id' => $this->ausess()['auid'],
                'operate_time' => time()
            ];
            $pay_log->save($update_data);
            // 修改客户状态
            $student = PayStudent::get($pay_log['pay_student_id']);
            if (!empty($student)){
                $student->status = 2;
                if ($pay_log['pay_price'] + $student['pay_price'] >= $student['total_price']){
                    $student->pay_end_time = time();
                    $student->pay_status = 1;
                }
                $student->save();
            }else{
                $company = CompanyCustomerBatch::get(['batch_number' => $pay_log['batch_number']]);
                if (!empty($company)){
                    if ($pay_log['pay_price'] + $company['pay_price'] >= $company['total_price']){
                        $company->pay_end_time = time();
                        $company->pay_status = 1;
                    }
                    $company->setInc('pay_price',$pay_log['pay_price']);
                }
            }
            $this->success('审核操作完成');
        }
    }

    /**
     * 业务提成列表
     * @return mixed
     * @throws DbException
     */
    public function deduct_index(){
        $where = [
            'department_id' => ['in','1,11,12']
        ];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $department_id = $this->ausess()['department_id'];
        if (!empty($department_id) && !in_array($department_id,['2','7'])){
            $where['id'] = $this->ausess()['auid'];
        }
        $aulist = AdminUser::all($where);
        $this->assign([
            'aulist' => $aulist
        ]);
        return  $this->fetch();
    }

    /**
     * 获取业务提成数据
     * @throws DbException
     */
    public function getDeductData(){
        $param = $this->request->param();
        $where = [];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        if (!empty($param['auid'])){
            $where['admin_id'] = $param['auid'];
        }
        $department_id = $this->ausess()['department_id'];
        if (!empty($department_id) && !in_array($department_id,['2','7'])){
            $where['admin_id'] = $this->ausess()['auid'];
        }
        // 创建时间
        if(isset($param['action_time']) && !empty($param['action_time'])){
            $where['create_time'] = ['>=' , strtotime($param['action_time'])];
        }
        // 创建时间截止查询时间
        if(isset($param['end_time']) && !empty($param['end_time'])){
            $end_time = strtotime(date($param['end_time'] . ' 23:59:59'));
            if (!empty($where['create_time'])){
                $where['create_time'] = ['between' , [strtotime($param['action_time']),$end_time]];
            }else{
                $where['create_time'] = ['<=' , $end_time];
            }

        }
        $list = (new AdminDeduct())
            ->with('admin,profession,student')
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit'])
            ->each(function ($item){
                $profession_top = C::get($item['profession']['pid']);
                $item['profession_name_text'] = $profession_top['name'] . ' - - ' . $item['profession']['name'];
                return $item;
            });
        $data = $list->items();
        layuiReturn(0,'',$list->count(),$data);
    }

    /**
     * 财务审核页面
     * @return mixed
     * @throws DbException
     */
    public function refund_index(){
        $where = [];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $aulist = AdminUser::all($where);
        $this->assign([
            'aulist' => $aulist,
            'admin' => $this->ausess(),
            'ware_id' => $this->request->param('ware_id','1')
        ]);
        return $this->fetch();
    }

    /**
     * 财务审核数据
     * @throws DbException
     */
    public function getRefundLogData(){
        $param = $this->request->param();
        $where = FinancingLogic::selectAuditParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        if (isset($where['status']) && $where['status'] == 0){
            $where['status'] = ['in','0,3,5'];
        }elseif (isset($where['status']) && $where['status'] == 2){
            $where['status'] = ['in','2,4,6'];
        }
        $list = (new RefundLog())
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        $list_items = $list->items();
        foreach ($list_items as $k => $v){
            // 客户信息
            if (!empty($v['batch_number'])){
                $batch_number = $v['batch_number'];
                $customer = (new \app\backend\model\Customer())
                    ->with('admin')
                    ->where(function ($query) use ($batch_number){
                        $customer_id = (new CompanyCustomerBatch())
                            ->where('batch_number',$batch_number)
                            ->value('customer_id');
                        $query->where('id',$customer_id);
                    })
                    ->find();
            }else{
                $pay_student_id = $v['pay_student_id'];
                $customer = (new \app\backend\model\Customer())
                    ->with('admin')
                    ->where(function ($query) use ($pay_student_id){
                        $customer_id = (new PayStudent())
                            ->where('id',$pay_student_id)
                            ->value('customer_id');
                        $query->where('id',$customer_id);
                    })
                    ->find();
                $pay_student = (new PayStudent())->with('admin')->find(['id' => $pay_student_id]);
                $list_items[$k]['pay_student'] = $pay_student;
            }
            $list_items[$k]['customer'] = $customer;
            // 操作人
            if (!empty($v['operate_id'])){
                $operate = AdminUser::get($v['operate_id']);
            }else{
                $operate = [
                    'real_name' => '未审核'
                ];
            }
            $list_items[$k]['operate'] = $operate;
            // 财务主管审核
            if (!empty($v['zg_check_id'])){
                $zg = AdminUser::get($v['zg_check_id']);
            }else{
                $zg = [
                    'real_name' => '未审核'
                ];
            }
            $list_items[$k]['zg'] = $zg;
            // 老板审核
            if (!empty($v['lb_check_id'])){
                $lb = AdminUser::get($v['lb_check_id']);
            }else{
                $lb = [
                    'real_name' => '未审核'
                ];
            }
            $list_items[$k]['lb'] = $lb;
        }
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $list_items);
    }

    /**
     * 财务审核查看
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function refund_detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new RefundLog())
                ->with(['student' => ['profession']])
                ->where('id',$param['id'])
                ->find()->toArray();
//            dump($ress);die;
        }else{
            $this->error('页面出错了！');
        }
        $data=['ress'=>$ress, 'param'=>$param];
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 退款审核拒绝操作
     * @return mixed
     * @throws DbException
     */
    public function refund_jujue(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            $pay_log = RefundLog::get($param['id']);
            $admin = $this->ausess();
            // 判断是否可以修改
            if (($pay_log['status'] >= 1 && $admin['group_id'] == 11)){
                $this->error('请勿重复审核');
            }
            if (($pay_log['status'] >= 3 && $admin['group_id'] == 11)){
                $this->error('请勿重复审核');
            }
            if (($pay_log['status'] >= 5 && $admin['group_id'] == 11)){
                $this->error('请勿重复审核');
            }
            // 修改支付记录，并判断权限
            $group_id = $this->ausess()['group_id'];
            if ($group_id == 14){
                // 老板
                $update_data = [
                    'status' => 6,
                    'lb_check' => 2,
                    'lb_check_id' => $this->ausess()['auid'],
                    'lb_check_time' => time(),
                    'lb_feedback' => $param['feedback']
                ];
            }elseif ($group_id == 10){
                // 财务主管
                $update_data = [
                    'status' => 4,
                    'zg_check' => 2,
                    'zg_check_id' => $this->ausess()['auid'],
                    'zg_check_time' => time(),
                    'zg_feedback' => $param['feedback']
                ];
            }elseif ($group_id == 11){
                // 财务主管
                $update_data = [
                    'status' => 2,
                    'operate_id' => $this->ausess()['auid'],
                    'check_time' => time(),
                    'feedback' => $param['feedback']
                ];
            }else{
                $this->error('请联系财务、财务主管或老板审核');
            }
            $pay_log->save($update_data);

            $this->success('审核操作完成');
        }
        $data = [
            'id' => $this->request->param('id')
        ];
        $this->assign('data',$data);
        return $this->fetch();
    }

    /**
     * 退款审核通过
     * @return mixed
     * @throws DbException
     */
    public function refund_tongyi(){
        if(request()->isPost()){
            $param = $this->request->param();
            $pay_log = RefundLog::get($param['id']);
            $admin = $this->ausess();
            // 判断是否可以修改
            if (($pay_log['status'] >= 1 && $admin['group_id'] == 11)){
                $this->error('请勿重复审核');
            }
            if (($pay_log['status'] >= 3 && $admin['group_id'] == 10)){
                $this->error('请勿重复审核');
            }
            if (($pay_log['status'] >= 5 && $admin['group_id'] == 14)){
                $this->error('请勿重复审核');
            }
            // 修改支付记录，并判断权限
            $group_id = $this->ausess()['group_id'];
            $admin_id = $this->ausess()['auid'];
            if ($group_id == 14){
                // 老板
                $update_data = [
                    'status' => 1,
                    'lb_check' => 1,
                    'lb_check_id' => $admin_id,
                    'lb_check_time' => time()
                ];
            }elseif ($group_id == 11){
                // 财务主管
                $update_data = [
                    'status' => 5,
                    'operate_id' => $admin_id,
                    'check_time' => time()
                ];
            }else{
                $this->error('请联系财务、财务主管或老板审核');
            }
            $pay_log->save($update_data);
            $this->success('审核操作完成');
        }
        $data = [
            'id' => $this->request->param('id')
        ];
        $this->assign('data',$data);
        return $this->fetch();
    }

    public function student(){
        $param=input('param.');
        if (empty($param['ware_id'])){
            $this->error('没有该权限');
        }
        if ($param['ware_id'] != 1){
            $this->error('没有该权限');
        }
        $batch = CompanyCustomerBatch::get($param['id']);
        $href = url($this->request->param('refund'),[
            'ware_id' => $this->request->param('ware_id',1)
        ]);
        $data=['param'=>$param,'refund' => $href];
        $this->assign('data',$data);
        $this->assign([
            'batch' => $batch
        ]);
        return  $this->fetch();
    }
}
