<?php
namespace app\backend\controller;

use app\backend\model\AdminDepartment;
use app\backend\model\TaskAccomplish;
use think\Controller;
use think\Exception;
use think\exception\DbException;
use think\response\View;
use think\Session;
use think\Request;
use app\backend\model\Task as N;

class Task extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $department = AdminDepartment::all();
        $this->assign([
            'department' => $department,
            'contents_check' => true
        ]);
    }

    /**
     * 列表
     * @return View
     * @throws DbException
     */
    public function index(){
        $i=new N();
        $where = [];
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }
        $res=$i
            ->where($where)
            ->whereOr(
                'department_id',0
            )
            ->paginate(15);
        $list=$res->toArray()['data'];
        return view('',[
           'data' => $list,
           'page' => $res->render()
        ]);
    }

    public function getMyData(){
        $i=new N();
        $where = [];
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }

        $res=$i->where($where)->whereOr('department_id',0)->paginate(15);
        $list=$res->toArray()['data'];
        foreach ($list as $k => $v){
            // 如果没有提交记录，则未完成
            $where = [
                'task_id' => $v['id'],
                'admin_id' => $this->ausess()['auid']
            ];
            $accomplish = (new TaskAccomplish())
                ->where($where)
                ->order('id DESC')
                ->find();
            $list[$k]['status_text'] = '未完成';
            if (empty($accomplish)){
                continue;
            }
            if ($accomplish['status'] == 1){
                $list[$k]['status_text'] = '已完成';
                continue;
            }
            if ($accomplish['status'] == 2){
                $list[$k]['status_text'] = '审核被拒';
                continue;
            }
            $list[$k]['status'] = $accomplish['status'];
        }
        layuiReturn($this->errCode('OK'), '获取成功', $res->count(), $list);
    }

    /**
     * 列表
     * @return View
     * @throws DbException
     */
    public function my_index(){
        $i=new N();
        $where = [];
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }

        $res=$i->where($where)->whereOr('department_id',0)->paginate(15);
        $list=$res->toArray()['data'];
        foreach ($list as $k => $v){
            // 如果没有提交记录，则未完成
            $where = [
                'task_id' => $v['id'],
                'admin_id' => $this->ausess()['auid']
            ];
            $accomplish = (new TaskAccomplish())
                ->where($where)
                ->order('id DESC')
                ->find();
            $list[$k]['status_text'] = '未完成';
            if (empty($accomplish)){
                continue;
            }
            if ($accomplish['status'] == 1){
                $list[$k]['status_text'] = '已完成';
                continue;
            }
            if ($accomplish['status'] == 2){
                $list[$k]['status_text'] = '审核被拒';
                continue;
            }
            $list[$k]['status'] = $accomplish['status'];
        }
        return view('',[
            'data' => $list,
            'page' => $res->render()
        ]);
    }

    /**
     * 详情
     * @return mixed
     * @throws DbException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function detail(){
        $id = $this->request->param('id');
        $data = N::get($id);
        $where = [
            'task_id' => $data['id'],
            'admin_id' => $this->ausess()['auid']
        ];
        $accomplish = (new TaskAccomplish())
            ->where($where)
            ->order('id DESC')
            ->find();
        $this->assign([
            'data' => $data,
            'accomplish' => $accomplish
        ]);
        return $this->fetch();
    }

    /**
     * 已完成
     * @throws DbException
     */
    public function end(){
        $param = $this->request->param();
        $task = N::get(!empty($param['id']) ? $param['id'] : 0);
        if (empty($task)){
            $this->error('任务不存在');
        }
        // 保存完成记录
        $data = [
            'remark' => $param['remark'],
            'campus_id' => $this->ausess()['campus_id'],
            'department_id' => $this->ausess()['department_id'],
            'task_id' => $param['id'],
            'admin_id' => $this->ausess()['auid']
        ];
        (new TaskAccomplish())->save($data);
        // 保存已完成成员
        $admin_ids = $task['admin_ids'];
        $admin_array = !empty($admin_ids) ? explode(',',$admin_ids) : [];
        $admin_array = array_merge($admin_array,[$this->ausess()['auid']]);
        sort($admin_array);
        $task->save([
            'admin_ids' => implode(',',$admin_array)
        ]);
        $this->success('任务完成申请已提交');
    }

    /**
     * 审核列表
     * @return View
     * @throws DbException
     */
    public function audit_index(){
        $i=new TaskAccomplish();
        $where = [
            'status' => 0
        ];
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }
        $res=$i->with('task,admin')->where($where)->paginate(15);
        $list=$res->toArray()['data'];
        return view('',[
            'data' => $list,
            'page' => $res->render()
        ]);
    }

    /**
     * 同意
     * @throws DbException
     */
    public function consent(){
        $task_a = TaskAccomplish::get($this->request->param('id'));
        $data = [
            'check_admin_id' => $this->ausess()['auid'],
            'check_time' => time(),
            'status' => 1
        ];
        $task_a->save($data);
        $this->success('审核成功');
    }

    /**
     * 拒绝
     * @throws DbException
     */
    public function refuse(){
        if ($this->request->isPost()){
            $task_a = TaskAccomplish::get($this->request->param('id'));
            $task = N::get($task_a['task_id']);
            $data = [
                'check_admin_id' => $this->ausess()['auid'],
                'check_time' => time(),
                'feedback' => $this->request->param('feedback'),
                'status' => 2
            ];
            $task_a->save($data);
            $admin_array = explode(',',$task['admin_ids']);
            foreach ($admin_array as $k => $v){
                if ($v == $task_a['admin_id']){
                    unset($admin_array[$k]);
                }
            }
            sort($admin_array);
            $task->save([
                'admin_ids' => implode(',',$admin_array)
            ]);
            $this->success('审核成功');
        }
        $this->assign([
            'id' => input('id')
        ]);
        return $this->fetch();
    }

    /**
     * 添加
     * @return bool|View
     */
    public function add(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new N();
            $this->addAction($model);
            return false;
        }

        return view('',[
            'url' => url('task/add')
        ]);
    }

    /**
     * 修改
     * @return bool|View
     * @throws Exception
     * @throws DbException
     */
    public function edit(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new N();
            $this->addAction($model);
            return false;
        }
        $id=input('id');
        $task=N::get($id);
        return view('add',[
            'data' => $task,
            'url' => url('task/edit')
        ]);
    }
    public function delData(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            (new N())->where('id','in',$this->request->param('id'))->delete();
            $this->success('删除成功');
        }
    }

    /**
     * 数据提交之前的操作
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return [array]
     */
    protected function before_add($data){
        if ($data['ware_id'] == 1 && !empty($data['department_id'])){
            $this->error('参数错误');
        }
        if ($data['ware_id'] == 2 && empty($data['department_id'])){
            $this->error('请选择部门');
        }
        if (empty($data['department_id'])){
            $data['department_id'] = 0;
        }
        if (!is_numeric($data['action_time'])){
            $data['action_time'] = strtotime($data['action_time']);
        }
        if (!is_numeric($data['end_time'])){
            $data['end_time'] = strtotime($data['end_time']);
        }
        if (!empty($this->campus_id)){
            $data['campus_id'] = $this->campus_id;
        }
        return $data;
    }
    /**
     * 数据提交之后的操作
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return []
     */
    protected function after_add($data){
    }

    /**
     * 数据提交之后写入数据库
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return []
     */
    protected function write_log($data){

    }
    /**
     * 数据删除之后的操作
     * @access public
     * @param  array  $data  数据
     * @since dxf
     * @return []
     */
    protected function after_del($data){
    }
}
