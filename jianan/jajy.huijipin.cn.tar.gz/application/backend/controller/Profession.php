<?php
namespace app\backend\controller;
use app\backend\logic\ProfessionLogic;
use think\Controller;
use think\Db;
use think\Config;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;
use think\Request;
use app\backend\model\ProfessionCate;
use app\backend\model\CustomerFrom;
use app\backend\model\CustomerRecord;
use app\backend\model\Profession as C;
use app\backend\logic\CustomerLogic;
use app\backend\model\ProfessionFields;
class Profession extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $cate_list= ProfessionCate::all();
        $pid = $this->request->param('pid');
        if (empty($pid)){
            $pro_list= C::all(['pid' => 0]);
        }
        else{
            $pro_list= C::all(['id' => $pid]);
        }
        $this->assign('cate_list',$cate_list);
        $this->assign('pro_list',$pro_list);
        $profession_fields = (new ProfessionFields())->order('id ASC')->select();
        $this->assign('profession_fields',$profession_fields);
    }

    /**
     * 客户列表
     * @access public
     * @return mixed [type] 页面
     * @since dxf
     */
    public function index(){
        return  $this->fetch();
    }
    /** 
     * 客户列表数据的获取
     * @access public 
     * @since dxf 
     * @return [json]  
     */ 
    public function getData(){
        $model=new C;
        $param=input('param.');
        $where=ProfessionLogic::selectParam($param,$this->ausess());
        $rs=$model->where($where)
            ->order('id DESC')->paginate($param['limit']);
        layuiReturn($this->errCode('OK'), '获取成功', $rs->total(), $rs->items());
    }

    /**
     * 获取下拉菜单数据
     * @throws DbException
     */
    public function selectData(){
        $cate_id = $this->request->param('cate_id');
        $data = C::all([
            'cate_id' => $cate_id,
            'pid' => 0
        ]);
        $data1 = [
            '0' => [
                'id' => 0,
                'name' => '无'
            ]
        ];
        foreach ($data as $k => $v){
            $data1[$k+1] = $v->toArray();
        }
        $this->success('','',$data1);
    }
    /**
     * 获取下拉菜单数据
     * @throws DbException
     */
    public function selectSonData(){
        $cate_id = $this->request->param('cate_id');
        $data = C::all([
            'pid' => $cate_id,
        ]);
        $this->success('','',$data);
    }
    /**
     * 获取工种报名费用
     * @throws DbException
     */
    public function getPrice(){
        $profession_id = $this->request->param('profession_id');
        $data = C::get($profession_id);
        $this->success('','',$data);
    }

    /**
     * 获取报名资料
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     * @throws DbException
     */
    public function getFields(){
        $profession_id = $this->request->param('profession_id');
        $profession = C::get($profession_id);
        $data = (new ProfessionFields())
            ->where('id','in',$profession['field_ids'])
            ->select();
        $this->success('','',$data);
    }

    /** 
     * 客户数据的删除
     * @access public 
     * @since dxf 
     * @return [json] 
     */ 
    public function delete(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $ress=$this->del($this->tableName1);
          return $ress;
       }
    }
    /** 
     * 客户添加和修改
     * @access public 
     * @since dxf 
     * @return [type] 页面 
     */ 
    public function add(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new C;
          $ress=$this->addAction($model);
      }else{
          $param=input('param.');
          $pid = input('pid');
          if (!empty($pid)) {
              $cate_id = (new C())->where('id',$pid)->value('cate_id');
          }
          if(!empty($param['id'])){
              $ress= C::get($param['id']);
              $ress['field_ids'] = !empty($ress['field_ids']) ? explode(',',$ress['field_ids']) : [];
              $pro_list = C::all(['id' => $ress['pid']]);
          }else{
              $ress=[
                  'cate_id'=>!empty($cate_id) ? $cate_id :'',
                  'pid'=>$pid,
                  'from'=>''
              ];
              $pro_list = [];
          }

          $data=['ress'=>$ress];
          $this->assign('pro_list',$pro_list);
          $this->assign('data',$data);
          return  $this->fetch();
      }
    }
    /** 
     * 客户详情
     * @access public 
     * @since dxf 
     * @return [type] 页面 
     */ 
    public function detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= C::get($param['id']);
            $catelist=CustomerCate::getAll(['status'=>1]);
            $record= CustomerRecord::getAll(['customer_id'=>$param['id']]);
        }else{
            $this->error('页面出错了！');
        }
        $data=['record'=>$record,'ress'=>$ress,'param'=>$param,'catelist'=>$catelist];
        $this->assign('data',$data);
        return  $this->fetch();
    }
    /** 
     * 客户回访记录的添加和修改
     * @access public 
     * @since dxf 
     * @return [type] 页面 
     */ 
    public function addRecord(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new CustomerRecord;
          $param = $this->request->param();
          $customer = C::get($param['customer_id']);
          if (!empty($param['contents'])){
              $data = [
                  'customer_id' => $customer['id'],
                  'auid' => $customer['auid'],
                  'group_id' => $customer['group_id'],
                  'contents' => $param['contents'],
                  'create_time' => time(),
              ];
              $model->save($data);
          }
          // 修改客户状态
          $customer_data = [];
          if (!empty($param['warn_time'])){
              $customer_data['next_contact_time'] = strtotime($param['warn_time']);
              $customer_data['end_time'] = time();
              $customer_data['follow_status'] = 1;
          }else{
              $customer_data['next_contact_time'] = '';
              $customer_data['end_time'] = time();
              $customer_data['follow_status'] = 2;
          }
          $result = $customer->save($customer_data);
          if ($result){
              ajaxReturn($this->errCode('OK'), '跟进记录保存成功');
          }else{
              ajaxReturn($this->errCode('SQLError'), '页面出错了');
          }
      }else{
          $param=input('param.');
          if(isset($param['id']) && !empty($param['id'])){
              $ress= C::get($param['id']);
              $catelist=CustomerCate::getAll(['status'=>1]);
          }else{
             $this->error('页面出错了！');
          }
          $data=['id'=>$param['id'],'catelist'=>$catelist,'ress'=>$ress];
          $this->assign('data',$data);
          return  $this->fetch();
      }
    }
    /** 
     * 客户数据下载
     * @access public 
     * @since dxf 
     * @return [type]  
     */ 
    public function down(){
      $model=new C;
      $param=input('param.');
      $where=CustomerLogic::selectParam($param,$this->ausess());
      $data=$model->get_down_list($param,$where);
      $excel_name='客户信息_'.date('YmdHis');
      CustomerLogic::down($data,$excel_name);
    }
    /** 
     * 客户数据导入的模板下载
     * @access public 
     * @since dxf 
     * @return [type]  
     */ 
    public function muban(){
      $rr=CustomerLogic::muban();
      $excel_name='客户信息导入模板'; 
      CustomerLogic::down($rr,$excel_name);
    }
    /** 
     * 客户数据导入
     * @access public 
     * @since dxf 
     * @return [type]  
     */
    public function leading(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $param=input('param.');
          $rss=CustomerLogic::uploadFile($param['fileurl'],$this->ausess());
          if($rss['status']==1){
            $model=new C;
            $re=$model->saveAll($rss['data']);
            if($re){
                ajaxReturn($this->errCode('OK'), '数据导入成功');
            }else{
                ajaxReturn($this->errCode('SQLError'), '数据导入失败了');
            }
          }else{
              ajaxReturn($this->errCode('SQLError'), $rss['msg']);
          }
      }else{
          return  $this->fetch();
      }
    }

    /**
     * 下次联系时间
     */
    public function nextTime(){
        $param = $this->request->param();
        $ids =  $param['ids'] ? $param['ids'] : false;
        $next_time = $this->request->param('next_time');

        if (empty($ids)){
            $this->error('请选择数据');
        }
        if (empty($next_time)){
            $this->error('请选择正确时间');
        }

        $data = [
            'next_contact_time' => strtotime($next_time),
            'follow_status' => 1
        ];

        $result = (new C())->where('id','in',$ids)->update($data);
        if ($result){
            $this->success('下次联系时间设置成功');
        }
    }

    /**
     * 跟进
     * @throws \think\Exception
     * @throws DbException
     */
    public function follow(){
        $id = $this->request->param('id');
        $customer = (new C())->with('admin')->where('id',$id)->find();
        $customer_record = (new CustomerRecord())->where(['customer_id' => $id])->order('id DESC')->select();
        $this->assign([
            'customer' => $customer,
            'customer_record' => $customer_record
        ]);
        return $this->fetch();
    }

    /** 
     * 数据提交之前的操作
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [array] 
     */
    protected function before_add($data){
      if(empty($data['warn_time'])){
        unset($data['warn_time']);
      }
      return $data;
    }
    /** 
     * 数据提交之后的操作
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [] 
     */
    protected function after_add($data){
        //更新客户表中的状态和下次提醒时间
        if(!empty($data['customer_id']) && !empty($data['cate_id'])){
          $model=new C;
          $updata['id']=$data['customer_id'];
          $updata['cate_id']=$data['cate_id'];
          $updata['warn_time']=strtotime($data['warn_time']);
          $ress=$model->update_data($updata);
        }
        // 增加两个子级栏目
        if (empty($data['pid']) && empty($data['id'])){
            $profession = (new C())
            ->order('id DESC')
            ->find();
            $add_data = [
                [
                    'name' => '新办',
                    'cate_id' => $data['cate_id'],
                    'pid' => $profession['id'],
                    'price' => $profession['price'],
                    'is_promote' => 2,
                    'field_ids' => $profession['field_ids'],
                    'admin1_deduct' => $profession['admin1_deduct'],
                    'admin2_deduct' => $profession['admin2_deduct'],
                    'admin3_deduct' => $profession['admin3_deduct'],
                ],
                [
                    'name' => '复审',
                    'cate_id' => $data['cate_id'],
                    'pid' => $profession['id'],
                    'price' => $profession['price'],
                    'is_promote' => 2,
                    'field_ids' => $profession['field_ids'],
                    'admin1_deduct' => $profession['admin1_deduct'],
                    'admin2_deduct' => $profession['admin2_deduct'],
                    'admin3_deduct' => $profession['admin3_deduct'],
                ],
            ];
            (new C())->saveAll($add_data);
        }
    }
    /** 
     * 数据提交之后写入数据库
     * @access public 
     * @param  array  $data  接收的数据
     * @since dxf 
     * @return [] 
     */
    protected function write_log($data){
      if(!empty($data['customer_id'])){
        $contents="添加回访数据！";
      }elseif(!empty($data['cate_id'])){
        $contents="添加 / 修改了客户数据，名称：$data[name]";
      }else{
        $contents="添加 / 修改了客户分类/来源数据，名称：$data[name]";
      }
      $this->writelog($contents);
      
    }
    /** 
     * 数据删除之后的操作
     * @access public 
     * @param  array  $data  数据
     * @since dxf 
     * @return [] 
     */
    protected function after_del($data){
      if(!empty($data['cate_id'])){
         $contents="删除了客户数据，名称：$data[name]";
      }else{
         $contents="删除了客户分类/来源数据：$data[name]";
      }
      $this->writelog($contents);
    }



}
