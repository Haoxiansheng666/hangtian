<?php
namespace app\backend\controller;
use app\backend\logic\WarehouseGoodsLogic;
use app\backend\model\WarehouseGoodsLoad;
use app\backend\model\WarehouseGoodsLoss;
use app\backend\model\WarehouseGoodsScrap;
use think\Controller;
use think\Db;
use think\Config;
use think\exception\DbException;
use think\Request;
use app\backend\model\CustomerCate;
use app\backend\model\CustomerFrom;
use app\backend\model\CustomerRecord;
use app\backend\model\Warehouse as C;
use app\backend\logic\WarehouseLogic;
use app\backend\model\AdminUser;
class Warehouse  extends Common
{   
    protected $tableName = 'customer_cate';
    protected $tableName1 = 'warehouse';

    public function __construct(Request $request = null)
    {
        parent::__construct($request);
    }

    /**
     * 仓库列表
     * @access public
     * @return mixed [type] 页面
     * @since dxf
     */
    public function index(){
        return  $this->fetch();
    }

    /** 
     * 仓库列表数据的获取
     * @access public 
     * @since dxf 
     * @return [json]  
     */ 
    public function getData(){
        $model=new C;
        $param=input('param.');
        $where=WarehouseLogic::selectParam($param,$this->ausess());
        $rs=$model->get_join_list($param,$where);
        layuiReturn($this->errCode('OK'), '获取成功', $rs['count'], $rs['list']);
    }

    /** 
     * 仓库数据的删除
     * @access public 
     * @since dxf 
     * @return [json] 
     */ 
    public function delete(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $ress=$this->del($this->tableName1);
          return $ress;
       }
    }

    /** 
     * 仓库添加和修改
     * @access public 
     * @since dxf 
     * @return [type] 页面 
     */ 
    public function add(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new C;
          $ress=$this->addAction($model);
      }else{
          $param=input('param.');
          $catelist=CustomerCate::getAll(['status'=>1]);
          $fromlist=CustomerFrom::getAll(['status'=>1]);
          if(!empty($param['id'])){
              $ress= C::get($param['id']);
          }else{
              $ress=[
                  'cate_id'=>'',
                  'province'=>'110000',
                  'city'=>'110100',
                  'county'=>'110113',
                  'from'=>''
              ];
          }
          $data=['ress'=>$ress,'fromlist'=>$fromlist,'catelist'=>$catelist];
          $this->assign('data',$data);
          return  $this->fetch();
      }
    }

    /**
     * 入库
     * @return mixed
     */
    public function add_inventory(){
        $id = $this->request->param('id');
        $this->assign([
            'warehouse_id' => $id
        ]);
        return $this->fetch('warehouse_goods/add');
    }

    /**
     * 库存
     * @return mixed
     */
    public function inventory(){

        return $this->fetch();
    }

    /**
     * 库存统计
     * @return mixed
     */
    public function inventory_statistics(){
        // 入库统计
        $load_total_list = (new WarehouseGoodsLoad())->select();
        $load_total_num = 0;
        $load_total_price = 0;
        foreach ($load_total_list as $k => $v){
            $load_total_num += $v['num'];
            $load_total_price += $v['num'] * $v['price'];
        }
        // 出库统计
        $loss_total_list = (new WarehouseGoodsLoss())->where('check_time','<>','')->select();
        $loss_total_num = 0;
        $loss_total_price = 0;
        foreach ($loss_total_list as $k => $v){
            $loss_total_num += $v['num'];
            $loss_total_price += $v['num'] * $v['price'];
        }
        // 报废统计
        $scrap_total_list = (new WarehouseGoodsScrap())->select();
        $scrap_total_num = 0;
        $scrap_total_price = 0;
        foreach ($scrap_total_list as $k => $v){
            $scrap_total_num += $v['num'];
            $scrap_total_price += $v['num'] * $v['price'];
        }
        $this->assign([
            'load_total_num' => $load_total_num,
            'load_total_price' => $load_total_price,
            'loss_total_num' => $loss_total_num,
            'loss_total_price' => $loss_total_price,
            'scrap_total_num' => $scrap_total_num,
            'scrap_total_price' => $scrap_total_price,
        ]);
        return $this->fetch();
    }

    /**
     * 获取库存统计数据
     * @throws DbException
     */
    public function getStatisticsData(){
        $param=input('param.');
        $where=[];
        $with = 'admin,goods';
        //客户名称
        if(isset($param['name']) && !empty($param['name'])){
            $where['name']=array('like',"%$param[name]%");
        }
        // 货品类型
        if(isset($param['type']) && !empty($param['type'])){
            $where['goods_type']=$param['type'];
        }
        if ($param['action'] == 1){
            // 入库
            $model = (new WarehouseGoodsLoad());
        }else if ($param['action'] == 2){
            // 出库
            $model = (new WarehouseGoodsLoss());
            $where['check_time'] = ['<>',''];
            $with .= ',checkAdmin';
        }else{
            // 报废
            $model = (new WarehouseGoodsScrap());
        }
        $rs = $model
            ->with($with)
            ->where($where)
            ->order('id DESC')
            ->paginate($param['limit']);
        $data = $rs->items();
        layuiReturn($this->errCode('OK'), '获取成功', $rs->total(), $data);
    }

    /**
     * 数据提交之前的操作
     * @access public
     * @param array $data 接收的数据
     * @return array
     */
    protected function before_add($data){

      return $data;
    }

    /** 
     * 数据提交之后的操作
     * @access public 
     * @param  array  $data  接收的数据
     */
    protected function after_add($data){
    }

    /** 
     * 数据提交之后写入数据库
     * @access public 
     * @param  array  $data  接收的数据
     */
    protected function write_log($data){
      if(!empty($data['customer_id'])){
        $contents="添加回访数据！";
      }elseif(!empty($data['cate_id'])){
        $contents="添加 / 修改了仓库数据，名称：$data[name]";
      }else{
        $contents="添加 / 修改了仓库分类/来源数据，名称：$data[name]";
      }
      $this->writelog($contents);
      
    }

    /** 
     * 数据删除之后的操作
     * @access public 
     * @param  array  $data  数据
     */
    protected function after_del($data){
      if(!empty($data['cate_id'])){
         $contents="删除了仓库数据，名称：$data[name]";
      }else{
         $contents="删除了仓库分类/来源数据：$data[name]";
      }
      $this->writelog($contents);
    }



}
