<?php
namespace app\backend\controller;
use app\backend\logic\PayStudentLogic;
use app\backend\model\Cert;
use app\backend\model\CompanyCustomerBatch;
use app\backend\model\ExamStudent;
use app\backend\model\GradeStudent;
use app\backend\model\InvoiceLog;
use app\backend\model\PayLog;
use app\backend\model\ProceedsType;
use app\backend\model\ProfessionCate;
use app\backend\model\RefundLog;
use app\backend\model\ServiceContact;
use think\Db;
use think\Config;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;
use think\Log;
use think\Request;
use app\backend\model\CustomerCate;
use app\backend\model\PayStudent as C;
use app\backend\logic\CustomerLogic;
use app\backend\model\AdminUser;
class PayStudent  extends Common
{   
    protected $tableName = 'customer_cate';
    protected $tableName1 = 'pay_student';

    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $cate_list=CustomerCate::getAll(['status'=>1]);
        $aulist=AdminUser::all();
        $this->assign('cate_list',$cate_list);
        $this->assign('aulist',$aulist);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        // 支付方式
        $proceeds_type = ProceedsType::all();
        $this->assign('proceeds_type',$proceeds_type);
        // 状态
        $status_list = (new C())->statusList();
        $this->assign('status_list',$status_list);
    }
    /** 学员列表 */
    /**
     * 客户列表
     * @access public
     * @return mixed [type] 页面
     */
    public function index(){
        $model=new C;
        $param=input('param.');
        $param['limit'] = !empty($param['limit']) ? $param['limit'] : 10;
        $where=CustomerLogic::selectParam($param,$this->ausess());

        $rs=$model->get_join_list($param,$where);
        foreach ($rs['list'] as $k => $v){
            // 是否可领证标志
            $rs['list'][$k]['lz'] = 1;
        }
        $this->assign([
            'count' => $rs['count'],
            'data' => $rs['list']
        ]);
        return  $this->fetch();
    }

    /**
     * 客户列表数据的获取
     * @access public
     * @return void [json]
     */
    public function get_index_data(){
        $model=new C;
        $param=input('param.');
        $where=PayStudentLogic::selectParam($param,$this->ausess());
//        if (empty($where['status'])){
//            $where['status'] = ['>',1];
//        }
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $rs=$model->get_join_list($param,$where);
        layuiReturn($this->errCode('OK'), '获取成功', $rs['count'], $rs['list']);
    }

    /**
     * 客户详情
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new C())
                ->with('profession,professionTop')
                ->where('id',$param['id'])
                ->find();
        }else{
            $this->error('页面出错了！');
        }
        // 缴费记录
        $pay_log = (new PayLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 培训记录
        $grade_student = (new GradeStudent())
            ->with('grade,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 考试记录
        $exam_student = (new ExamStudent())
            ->with('exam,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 退费记录
        $refund_log = (new RefundLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 发票记录
        $invoice_log = (new InvoiceLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        $this->assign([
            'pay_log' => $pay_log,
            'grade_student' => $grade_student,
            'exam_student' => $exam_student,
            'refund_log' => $refund_log,
            'invoice_log' => $invoice_log,
        ]);
        $data=['ress'=>$ress, 'param'=>$param];
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 客户详情
     * @access public
     * @return mixed [type] 页面
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function audit_detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new C())
                ->with('profession,professionTop')
                ->where('id',$param['id'])
                ->find();
        }else{
            $this->error('页面出错了！');
        }
        // 缴费记录
        $pay_log = (new PayLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 培训记录
        $grade_student = (new GradeStudent())
            ->with('grade,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 考试记录
        $exam_student = (new ExamStudent())
            ->with('exam,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 退费记录
        $refund_log = (new RefundLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
//        var_dump($refund_log);die;
        // 发票记录
        $invoice_log = (new InvoiceLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        $this->assign([
            'pay_log' => $pay_log,
            'grade_student' => $grade_student,
            'exam_student' => $exam_student,
            'refund_log' => $refund_log,
            'invoice_log' => $invoice_log,
            'ware_id' => $param['ware_id']
        ]);
        $data=['ress'=>$ress, 'param'=>$param];
        $this->assign('data',$data);
        return  $this->fetch();
    }

    /**
     * 客户数据下载
     * @access public
     * @return void [type]
     */
    public function down(){
        $model=new C;
        $param=input('param.');
        $where=PayStudentLogic::selectParam($param,$this->ausess());
//        var_dump($where);die;
        $data=$model->get_down_list($param,$where);
        $excel_name='学员信息_'.date('YmdHis');
        PayStudentLogic::down($data,$excel_name);
    }

    /**
     * 客户数据导入的模板下载
     * @access public
     * @return void [type]
     */
    public function muban(){
        $rr=PayStudentLogic::muban();
        $excel_name='客户信息导入模板';
        PayStudentLogic::down($rr,$excel_name);
    }

    /**
     * 客户数据导入
     * @access public
     * @return mixed [type]
     * @throws DbException
     */
    public function leading(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param=input('param.');
            $rss=PayStudentLogic::uploadFile($param['fileurl'],$this->campus_id);
            if($rss['status']==1){
                $count_data = count($rss['data']);
                if (!empty($param['apply_num']) && $count_data != $param['apply_num']){
                    $this->error('输入报名人数与实际人数不符，实际人数:'.$count_data);
                }
                /** 关联客户 */
                // 如果选定客户则保存
                if (!empty($param['customer_id'])){
                    $customer_id = $param['customer_id'];
                    $customer = \app\backend\model\Customer::get($customer_id);
                    $campus_id = $customer['campus_id'];
                }else{
                    $this->error('企业客户不存在，请先添加企业客户');
                }
                /** 关联客户 end */
                /** 批次号处理 */
                // 自定义批次号可指定增加或替换默认批次号
                if (!empty($param['batch_number'])){
                    $batch_number = $param['batch_number'];
                    $batch = CompanyCustomerBatch::get(['batch_number' => $batch_number]);
                    // 批次号已存在则在原有基础上增加人数及价格
                    if (!empty($batch)){
                        $batch_data = [
                            'apply_num' => Db::raw('apply_num+'.$count_data),
                            'total_price' => Db::raw('total_price+'.$param['total_price']),
                        ];
                    }else{
                        $batch_data = [
                            'customer_id' => $customer_id,
                            'campus_id' => $campus_id,
                            'batch_number' => $batch_number,
                            'apply_num' => $count_data,
                            'total_price' => $param['total_price'],
                        ];
                    }
                }else{
                    $batch_number = date('YmdHis');
                    $batch_data = [
                        'customer_id' => $customer_id,
                        'campus_id' => $campus_id,
                        'batch_number' => $batch_number,
                        'apply_num' => $count_data,
                        'total_price' => $param['total_price'],
                    ];
                    $batch = new CompanyCustomerBatch();
                }
                $res1 = $batch->save($batch_data);
                if ($res1 === false){
                    $this->error('服务器错误,控制器:PayStudent,方法:leading');
                }
                /** 批次号处理 end */
                foreach ($rss['data'] as $k => $v){
                    $rss['data'][$k]['customer_id'] = $customer_id;
                    $rss['data'][$k]['batch_number'] = $batch_number;
                }

                $model=new C;
                $re=$model->saveAll($rss['data']);
                if($re){
                    $this->success('数据导入成功');
                }else{
                    $this->error('数据导入失败了');
                }
            }else{
                ajaxReturn($this->errCode('SQLError'), $rss['msg']);
            }
        }else{
            $company_customer = \app\backend\model\Customer::all([
                'from' => 2
            ]);
            $this->assign([
                'company_customer' => $company_customer
            ]);
            return  $this->fetch();
        }
    }
    /** 学员列表 end */

    /** 已报名客户列表 */
    /**
     * 已报名客户列表
     * @access public
     * @return mixed [type] 页面
     * @since dxf
     */
    public function customer_index(){
        return  $this->fetch();
    }

    /**
     * 获取客户列表数据
     */
    public function get_customer_index_data(){
        $model=new C;
        $param=input('param.');
        $where=PayStudentLogic::selectParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $rs=$model->get_join_list($param,$where);
        layuiReturn($this->errCode('OK'), '获取成功', $rs['count'], $rs['list']);
    }

    /**
     * 提交缴费申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function pay_money(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            // 增加缴费记录
            $res = (new PayLog())->allowField(true)->save($param);
            if ($res){
                $this->success('缴费审核已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $profession_top = \app\backend\model\Profession::get($profession['pid']);
            $customer['profession_name'] = $profession_top['name'] . '-' . $profession['name'];
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer,
                'profession' => $profession
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交退费申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function refund(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            // 增加退费记录
            $res = (new RefundLog())->allowField(true)->save($param);
            if ($res){
                $this->success('退费审核已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $profession_top = \app\backend\model\Profession::get($customer['profession_top_id']);
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer,
                'profession' => $profession,
                'profession_top' => $profession_top
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交发票申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function invoice(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            // 增加发票记录
            $res = (new InvoiceLog())->allowField(true)->save($param);
            if ($res){
                $this->success('发票审核已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer,
                'profession' => $profession
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交领证申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function get_certificate(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            $pay_student = C::get($param['pay_student_id']);
            // 增加校区字段
            if (!empty($pay_student['campus_id'])){
                $param['campus_id'] = $pay_student['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            $cert = Cert::get([
                'pay_student_id' => $param['pay_student_id'],
            ]);
            if (!empty($cert)){
                $this->success('领证申请已提交');
            }
            // 增加领证记录
            $res = (new Cert())->allowField(true)->save($param);
            if ($res){
                $this->success('领证申请已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $cert = Cert::get([
                'pay_student_id' => $id
            ]);
            $this->assign([
                'data' => $customer,
                'profession' => $profession,
                'cert' => $cert
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交领证申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function get_certificate_s(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            $pay_student = C::get($param['pay_student_id']);
            // 增加校区字段
            if (!empty($pay_student['campus_id'])){
                $param['campus_id'] = $pay_student['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            $cert = Cert::get([
                'pay_student_id' => $param['pay_student_id'],
            ]);
            if (!empty($cert)){
                $this->success('领证申请已提交');
            }
            // 增加领证记录
            $res = (new Cert())->allowField(true)->save($param);
            if ($res){
                $this->success('领证申请已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $cert = Cert::get([
                'pay_student_id' => $id
            ]);
            $this->assign([
                'data' => $customer,
                'profession' => $profession,
                'cert' => $cert
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交缴费申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function supplementary(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            // 增加缴费记录
            $res = (new PayLog())->allowField(true)->save($param);
            if ($res){
                $this->success('缴费审核已提交');
            }
            $this->error('提交失败');
        }else {
            $id = $this->request->param('id');
            $customer = (new C())->with('admin')->where('id', $id)->find();
            $customer['customer_id'] = $customer['id'];
            $customer['pid'] = 0;
            unset($customer['id']);
            $profession = \app\backend\model\Profession::get($customer['profession_id']);
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer,
                'profession' => $profession
            ]);
            return $this->fetch();
        }
    }

    /**
     * 提交缴费申请
     * @return mixed|void
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function reload_pay(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            $student = C::get($param['id']);
            $profession = (new \app\backend\model\Profession())
                ->where('id',$param['profession_id'])
                ->find();
            if (empty($profession)){
                $this->error('请选择工种类型');
            }
            if ($profession['name'] == '复审'){
                $param['user_type'] = 2;
            }else{
                $param['user_type'] = 1;
            }
            $param['status'] = 1;
            // 修改学员状态为待财务审核
            $student->save($param);
            $this->success('重新提交审核成功');
        }else {
            $id = $this->request->param('id');
            $customer = C::get($id);
            if (!empty($customer['id'])){
                $customer['pid'] = 0;
                // 查询学员工种上级栏目ID
                $profession = \app\backend\model\Profession::get($customer['profession_id']);
                $cate_id = ProfessionCate::get($profession['cate_id']);
                $customer['cate_id'] = $cate_id['id'];
                $customer['pid'] = $profession['pid'];
                $customer['profession_fields_array'] = explode(',',$customer['profession_fields']);
                $customer['profession_fields_array'] = json_encode($customer['profession_fields_array']);
            }
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer
            ]);
            return $this->fetch();
        }
    }

    /**
     * 已报名客户
     * @access public
     * @return mixed [type] 页面
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function customer_detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new C())
                ->with('profession')
                ->where('id',$param['id'])
                ->find();
        }else{
            $this->error('页面出错了！');
        }
        // 缴费记录
        $pay_log = (new PayLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 培训记录
        $grade_student = (new GradeStudent())
            ->with('grade,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 考试记录
        $exam_student = (new ExamStudent())
            ->with('exam,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 退费记录
        $refund_log = (new RefundLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 发票记录
        $invoice_log = (new InvoiceLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        $contact_log = (new ServiceContact())
            ->with('grade,exam,admin')
            ->where('pay_student_id',$ress['id'])
            ->select();

        $this->assign([
            'pay_log' => $pay_log,
            'grade_student' => $grade_student,
            'exam_student' => $exam_student,
            'refund_log' => $refund_log,
            'invoice_log' => $invoice_log,
            'contact_log' => $contact_log,
        ]);
        $data=['ress'=>$ress, 'param'=>$param];
        $this->assign('data',$data);
        return  $this->fetch();
    }
    /** 已报名客户列表 end */

    /** 报名审核列表  */
    /**
     * 报名审核列表
     * @access public
     * @return mixed [type] 页面
     * @since dxf
     */
    public function index_audit(){
        $this->assign([
            'ware_id' => $this->request->param('ware_id','1')
        ]);
        return  $this->fetch();
    }

    /**
     * 报名资料审核数据的获取
     * @access public
     * @return void [json]
     */
    public function get_index_audit_data(){
        $model=new C;
        $param=input('param.');
        $param['fa'] = true;
        $where=CustomerLogic::selectParam($param,$this->ausess());
        if (empty($where['status'])){
            $where['status'] = ['in','1,11'];
        }
        $rs=$model->get_join_list($param,$where);
        layuiReturn($this->errCode('OK'), '获取成功', $rs['count'],$rs['list']);
    }

    /**
     * 审核通过
     * @throws DbException
     */
    public function consent(){
        $id = $this->request->param('id');
        $student = C::get($id);
        if (empty($student)){
            $this->error('服务器错误');
        }
        // 修改报名客户信息
        $student->status = 11;
        $student->check_time = time();
        // 增加财务支付记录
        $pay_log_data = [
            'pay_student_id' => $student['id'],
            'pay_price' => $student['pay_price'],
            'pay_way' => $student['pay_way'],
            'pay_site' => $student['pay_site'],
            'proceeds_type' => $student['proceeds_type'],
            'pay_proof' => $student['pay_proof'],
            'remark' => $student['remark'],
            'pay_time' => !is_numeric($student['pay_time']) ? strtotime($student['pay_time']) : $student['pay_time'],
        ];
        // 增加校区字段
        if (!empty($this->ausess()['campus_id'])){
            $pay_log_data['campus_id'] = $this->ausess()['campus_id'];
        }else{
            $pay_log_data['campus_id'] = 1;
        }
        (new PayLog())->save($pay_log_data);
        $student->save();
        $this->success('已提交财务审核');
    }

    /**
     * 审核拒绝
     * @return mixed
     * @throws DbException
     */
    public function refuse(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $param = $this->request->param();
            if (empty($param['id'])){
                $this->error('服务器错误');
            }
            // 修改学员信息
            $student = C::get($param['id']);
            $res = $student->allowField(true)->save($param);
            if ($res){
                $this->success('此学员审核已被驳回');
            }
            $this->error('提交失败');
        }
        $this->assign([
            'id' => $this->request->param('id')
        ]);
        return $this->fetch();
    }
    /** 报名审核列表 end */

    /**
     * 客户数据的删除
     * @access public
     * @return void [json]
     */
    public function delete(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $ress=$this->del($this->tableName1);
          return $ress;
       }
    }

    /**
     * 客户添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function add(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $model=new C;
          $this->addAction($model);
      }else{
          $id = $this->request->param('id');
          $customer = C::get($id);
          if (!empty($customer['id'])){
              $customer['pid'] = 0;
              // 查询学员工种上级栏目ID
              $profession = \app\backend\model\Profession::get($customer['profession_id']);
              $cate_id = ProfessionCate::get($profession['cate_id']);
              $customer['cate_id'] = $cate_id['id'];
              $customer['pid'] = $profession['pid'];
              $customer['profession_fields_array'] = explode(',',$customer['profession_fields']);
              $customer['profession_fields_array'] = json_encode($customer['profession_fields_array']);
          }
          $admin = AdminUser::all();
          $this->assign([
              'admin' => $admin,
              'data' => $customer
          ]);
          return $this->fetch();
      }
    }

    /**
     * 客户添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function edit(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new C;
            $this->addAction($model);
        }else{
            $id = $this->request->param('id');
            $customer = C::get($id);
            if (!empty($customer['id'])){
                $customer['pid'] = 0;
                // 查询学员工种上级栏目ID
                $profession = \app\backend\model\Profession::get($customer['profession_id']);
                $cate_id = ProfessionCate::get($profession['cate_id']);
                $customer['cate_id'] = $cate_id['id'];
                $customer['pid'] = $profession['pid'];
                $customer['profession_fields_array'] = explode(',',$customer['profession_fields']);
                $customer['profession_fields_array'] = json_encode($customer['profession_fields_array']);
            }
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer
            ]);
            return $this->fetch();
        }
    }

    /**
     * 客户添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function audit_edit(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new C;
            $this->addAction($model);
        }else{
            $id = $this->request->param('id');
            $customer = C::get($id);
            if (!empty($customer['id'])){
                $customer['pid'] = 0;
                // 查询学员工种上级栏目ID
                $profession = \app\backend\model\Profession::get($customer['profession_id']);
                $cate_id = ProfessionCate::get($profession['cate_id']);
                $customer['cate_id'] = $cate_id['id'];
                $customer['pid'] = $profession['pid'];
                $customer['profession_fields_array'] = explode(',',$customer['profession_fields']);
                $customer['profession_fields_array'] = json_encode($customer['profession_fields_array']);
            }
            $admin = AdminUser::all();
            $this->assign([
                'admin' => $admin,
                'data' => $customer
            ]);
            return $this->fetch();
        }
    }

    /**
     * 客户添加和修改
     * @access public
     * @return mixed|void
     * @throws DbException
     */
    public function repetition(){
      if(var_export(Request::instance()->isAjax(), true)==='true'){
          $param = $this->request->param();
          // 增加校区字段
          if (!empty($this->ausess()['campus_id'])){
              $param['campus_id'] = $this->ausess()['campus_id'];
          }else{
              $param['campus_id'] = 1;
          }
          $student = C::get($param['id']);
          $profession = (new \app\backend\model\Profession())
              ->where('id',$param['profession_id'])
              ->find();
          if (empty($profession)){
              $this->error('请选择工种类型');
          }
          if ($profession['name'] == '复审'){
              $param['user_type'] = 2;
          }else{
              $param['user_type'] = 1;
          }
          $param['status'] = 1;
          // 修改学员状态为待财务审核
          $student->save($param);
          $this->success('重新提交审核成功');
      }else{
          $id = $this->request->param('id');
          $customer = C::get($id);
          if (!empty($customer['id'])){
              $customer['pid'] = 0;
              // 查询学员工种上级栏目ID
              $profession = \app\backend\model\Profession::get($customer['profession_id']);
              $cate_id = ProfessionCate::get($profession['cate_id']);
              $customer['cate_id'] = $cate_id['id'];
              $customer['pid'] = $profession['pid'];
              $customer['profession_fields_array'] = explode(',',$customer['profession_fields']);
              $customer['profession_fields_array'] = json_encode($customer['profession_fields_array']);
          }
          $admin = AdminUser::all();
          $this->assign([
              'admin' => $admin,
              'data' => $customer
          ]);
          return $this->fetch();
      }
    }

    public function success_exam(){
        $id = $this->request->param('id');
        $pay_student = C::get($id);
        $pay_student->save([
            'exam_status' => 1
        ]);
        $this->success('学员可考试状态已修改');
    }

    public function error_exam(){
        $id = $this->request->param('id');
        $pay_student = C::get($id);
        $pay_student->save([
            'exam_status' => 0
        ]);
        $this->success('学员可考试状态已修改');
    }

    /**
     * 数据提交之前的操作
     * @access public
     * @param array $data 接收的数据
     * @return array [array]
     * @throws DbException
     */
    protected function before_add($data){
        if (!empty($data['id'])){
            $student = C::get($data['id']);
            if ($student['status'] == '-3'){
                $data['status'] = 1;
            }
        }
        foreach ($data as $k => $v){
            if (strpos($k,'_time') != false && strpos($v,'-')){
                $data[$k] = strtotime($v);
            }
        }
        $profession = (new \app\backend\model\Profession())
            ->where('id',$data['profession_id'])
            ->find();
        if (empty($profession)){
            $this->error('请选择工种类型');
        }
        if ($profession['name'] == '复审'){
            $data['user_type'] = 2;
        }else{
            $data['user_type'] = 1;
        }
        if (!empty($data['from']) && $data['from'] == 2 && empty($data['company'])){
            $this->error('请输入单位名称');
        }
        // 增加校区字段
        if (!empty($this->ausess()['campus_id'])){
            $data['campus_id'] = $this->ausess()['campus_id'];
        }else{
            $data['campus_id'] = 1;
        }
      return $data;
    }

    /**
     * 数据提交之后的操作
     * @access public
     * @param array $data 接收的数据
     * @return void
     */
    protected function after_add($data){
        // 判断信息是否存在意向客户表，若无意向客户则添加
    }

    /**
     * 数据提交之后写入数据库
     * @access public
     * @param array $data 接收的数据
     * @return void
     */
    protected function write_log($data){
      if(!empty($data['customer_id'])){
        $contents="添加回访数据！";
      }elseif(!empty($data['cate_id'])){
        $contents="添加 / 修改了客户数据，名称：$data[name]";
      }else{
        $contents="添加 / 修改了客户分类/来源数据，名称：$data[name]";
      }
      $this->writelog($contents);
      
    }

    /**
     * 数据删除之后的操作
     * @access public
     * @param array $data 数据
     * @return void
     */
    protected function after_del($data){
      if(!empty($data['cate_id'])){
         $contents="删除了客户数据，名称：$data[name]";
      }else{
         $contents="删除了客户分类/来源数据：$data[name]";
      }
      $this->writelog($contents);
    }

}
