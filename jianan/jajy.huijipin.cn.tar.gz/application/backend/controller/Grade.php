<?php
namespace app\backend\controller;
use app\backend\logic\GradeLogic;
use app\backend\model\ExamStudent;
use app\backend\model\GradeStudent;
use app\backend\model\InvoiceLog;
use app\backend\model\PayLog;
use app\backend\model\PayStudent as C;
use app\backend\model\ProfessionCate;
use app\backend\model\RefundLog;
use think\Db;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\Exception;
use think\exception\DbException;
use think\Log;
use think\Request;
use app\backend\model\AdminUser;
use app\backend\model\Grade as G;
class Grade  extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        // 班主任
        $aulist=AdminUser::all(['group_id' => 4]);
        $this->assign('aulist',$aulist);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        // 状态
        $status = (new G)->getStatusArray();
        $this->assign('status_list',$status);
    }

    /**
     * 线上班级列表页面
     * @return mixed
     */
    public function ol_index(){
        return $this->fetch();
    }

    /**
     * 获取线上班级数据
     * @throws DbException
     */
    public function getOlData(){
        $where = GradeLogic::selectParam($this->request->param(),$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new G())
            ->with('teacher,admin,profession')
            ->where($where)
            ->where('train_site',1)
            ->order('id DESC')
            ->paginate($this->request->param('limit'))
            ->each(function ($item){
                $profession_top = \app\backend\model\Profession::get($item['profession']['pid']);
                $item['profession_name_text'] = $profession_top['name'] . ' - - ' .$item['profession']['name'];
                return $item;
            });
        $data = $list->items();
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $data);
    }

    /**
     * 线下班级列表页面
     * @return mixed
     */
    public function offline_index(){
        return $this->fetch();
    }

    /**
     * 获取线下班级数据
     * @throws DbException
     */
    public function getOfflineData(){
        $where = GradeLogic::selectParam($this->request->param(),$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new G())
            ->with('teacher,admin,profession')
            ->where($where)
            ->where('train_site',2)
            ->order('id DESC')
            ->paginate($this->request->param('limit'))
            ->each(function ($item){
                $profession_top = \app\backend\model\Profession::get($item['profession']['pid']);
                $item['profession_name_text'] = $profession_top['name'] . ' - - ' .$item['profession']['name'];
                return $item;
            });
        $data = $list->items();
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $data);
    }

    /**
     * 增加班级
     * @return mixed
     * @throws DbException
     */
    public function add(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new G();
            $ress=$this->addAction($model);
        }
        $param = $this->request->param();
        $res = [];
        if (!empty($param['id'])){
            $res = G::get($param['id']);
            $profession = \app\backend\model\Profession::get($res['profession_id']);
            $res['cate_id'] = $profession['cate_id'];
            $res['pid'] = $profession['pid'];
        }
        // 指定培训地点  线上|线下
        if (!empty($param['train_site'])){
            $res['train_site'] = $param['train_site'];
        }
        $this->assign([
            'res' => $res
        ]);
        return $this->fetch();
    }

    /**
     * 删除操作
     */
    public function delete(){
        $param = $this->request->param();
        if (!empty($param['id'])){
            $where = ['id' => $param['id']];
        }elseif(!empty($param['ids'])){
            $where = ['id' => ['in',$param['ids']]];
        }else{
            $this->error('访问方法错误');
        }
        $grade_student = (new GradeStudent())
            ->where([
                'grade_id' => $where['id']
            ])
            ->find();
        if (!empty($grade_student)){
            $this->error('请先移除班级内成员');
        }
        (new G())->where($where)->delete();
        $this->success('删除数据成功');
    }

    /**
     * 班级学员列表
     * @return mixed
     */
    public function student(){
        $id = $this->request->param('id');
        $this->assign([
            'id' => $id
        ]);
        return $this->fetch();
    }

    /**
     * 获取已选中学员
     * @throws DbException
     */
    public function getStudentData(){
        $param = $this->request->param();
        $where = GradeLogic::selectStudentParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new GradeStudent())
            ->with('payStudent')
            ->where($where)
            ->paginate($param['limit']);
        $data = $list->items();
        foreach ($data as $k => $v){
            // 增加学员关联的业务员及报名资料
            $profession_id = $v['pay_student']['profession_id'];
            $admin_id = $v['pay_student']['auid'];
            $profession = \app\backend\model\Profession::get($profession_id);
            $profession_top = \app\backend\model\Profession::get($profession['pid']);
            $admin = AdminUser::get($admin_id);
            $data[$k]['profession'] = $profession;
            $data[$k]['profession_name'] = $profession_top['name'] . ' - - ' . $profession['name'];
            $data[$k]['admin'] = $admin;
        }
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $data);
    }

    /**
     * 移出班级内学员
     */
    public function studentDelete(){
        $param = $this->request->param();
        // 删除学员关联关系并更改学员状态，减少班级学员人数
        Db::startTrans();
        try {
            $grade_student = GradeStudent::get($param['id']);
            $grade = G::get($grade_student['grade_id']);
            $update_data = [];
            if ($grade['train_site'] == 1){
                $update_data['ol_status'] = 2;
            }else{
                $update_data['offline_status'] = 2;
            }
            // 更改学员状态
            (new C())
                ->where('id','in',$grade_student['pay_student_id'])
                ->update($update_data);
            // 减少班级学员人数
            (new G())
                ->where('id',$grade_student['grade_id'])
                ->setDec('pay_student_num',1);
            // 删除关联关系
            $grade_student->delete();
            Db::commit();
        }catch (Exception $exception){
            Db::rollback();
            Log::write('学员删除:' . json_encode($exception->getMessage()));
        }
        $this->success('学员已移出班级');
    }

    /**
     * 选择学员
     * @return mixed
     */
    public function studentCheck(){
        $grade_id = $this->request->param('grade_id');
        $id = $this->request->param('id');
        $this->assign([
            'grade_id' => $grade_id,
            'id' => $id
        ]);
        return $this->fetch();
    }

    /**
     * 获取待培训学员数据
     * @throws DbException
     */
    public function getStudentCheckData(){
        $param = $this->request->param();
        $where = GradeLogic::selectStudentCheckParam($param,$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $other_where = ['status' => 2];
        if (!empty($param['grade_id'])){
            $grade = G::get($param['grade_id']);
            if ($grade['train_site'] == 1){
                $other_where['ol_status'] = 2;
            }else{
                $other_where['offline_status'] = 2;
            }

            if (!empty($grade['campus_id'])){
                $where['campus_id'] = $grade['campus_id'];
            }
            $where['profession_id'] = $grade['profession_id'];
        }
        $list = (new C())
            ->with('admin,profession')
            ->where($other_where)
            ->whereNotNull('pay_time')
            ->where($where)
            ->order('pay_time ASC')
            ->paginate($param['limit']);
        $data = $list->items();
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $data);
    }

    /**
     * 选中学员添加进班级
     * @throws DbException
     * @throws Exception
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function check_student_ids(){
        $param = $this->request->param();
        if (empty($param['grade_id'])){
            $this->error('班级不存在');
        }
        $grade = G::get($param['grade_id']);
        // 班级内已有学员人数
        $grade_student_count = (new GradeStudent())
            ->where('grade_id',$param['grade_id'])
            ->count();
        // 批量添加
        if (!empty($param['did'])){
            $did = is_array($param['did']) ? $param['did'] : (strpos($param['did'],',') != false ? explode(',',$param['did']) : [$param['did']]);
            foreach ($did as $k => $v){
                $data = [
                    'grade_id' => $param['grade_id'],
                    'pay_student_id' => $v
                ];
                // 增加校区字段
                if (!empty($this->ausess()['campus_id'])){
                    $data['campus_id'] = $this->ausess()['campus_id'];
                }else{
                    $data['campus_id'] = 1;
                }
                $student_list[] = $data;

            }
            $pay_student = (new C())
                ->where('id','in',$did)
                ->select();
        }
        // 单个选择
        if (!empty($param['id'])){
            $did = $param['id'];
            $data = [
                'grade_id' => $param['grade_id'],
                'pay_student_id' => $param['id']
            ];
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $data['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $data['campus_id'] = 1;
            }
            $student_list[] = $data;

            $pay_student = (new C())
                ->where('id',$param['id'])
                ->select();
        }
        // 根据学员信息判断是否可添加
        foreach ($pay_student as $k => $v){
            // 工种不同
            if ($v['profession_id'] != $grade['profession_id']){
                $this->error($v['name'] . '的工种与班级工种不匹配');
            }
            // 学员状态异常
            if ($v['status'] != 2){
                $this->error($v['name'] . '状态异常');
            }
            // 学员如果已经被选中
            $grade_status = (new GradeStudent())
                ->where('pay_student_id',$v['id'])
                ->find();
            $grade_join = G::get($grade_status['grade_id']);
            if (!empty($grade_status) && $grade['train_site'] == $grade_join['train_site']){
                $this->error($v['name'] . '已参加其他班级');
            }
        }
        $new_student_count = count($student_list);
        // 判断人数上限
        $total = $grade_student_count + $new_student_count;
        // 如果更换学员，人数需要减一
        if (!empty($param['student_id'])){
            $total = $total - 1 ;
        }
        if ($grade['student_num'] < $total){
            $this->error('班级学员人数上限:'.$grade['student_num'].'，本次添加后学员人数:' . $total);
        }

        // 增加班级学员关联及班级学员人数
        Db::startTrans();
        try {
            // 增加班级学员关联
            (new GradeStudent())->saveAll($student_list);
            if (empty($param['student_id'])){
                // 增加班级学员人数
                $grade->setInc('pay_student_num',$new_student_count);
            }
            // 修改学员状态
            if ($grade['train_site'] == 1){
                $student_data['ol_status'] = 3;
            }else{
                $student_data['offline_status'] = 3;
            }
            (new C())
                ->where('id','in',$did)
                ->update($student_data);
            if (!empty($param['student_id'])){
                // 如果更换学员把旧学员关联删除
                (new GradeStudent())->where([
                    'grade_id' => $grade['id'],
                    'pay_student_id' => $param['student_id']
                ])->delete();
                // 修改旧学员状态
                (new C())
                    ->where('id',$param['student_id'])
                    ->update([
                        'status' => 2
                    ]);
            }
            Db::commit();
        }catch (Exception $exception){
            Db::rollback();
            Log::write('添加班级学员：' . json_encode($exception->getMessage()));
            $this->error('系统错误');
        }
        $this->success('学员已添加进班级');
    }

    /**
     * 班级课程完成
     * @throws DbException
     */
    public function end(){
        $id = $this->request->param('id');
        $grade = G::get($id);
        // 根据可考试状态修改学员状态
        if ($grade['student_status'] == 1){
            $student_ids = (new GradeStudent())
                ->where([
                    'contact_status' => 1,
                    'status' => 0
                ])
                ->column('pay_student_id');
            $data = [
                'status' => 4
            ];
            if ($grade['train_site'] == 1){
                $data['ol_status'] = 1;
            }else{
                $data['offline_status'] = 1;
            }
            if($student_ids){
                (new C())->whereIn('id',$student_ids)->update($data);
            }
        }
        // 修改班级状态
        $grade->save([
            'status' => 2,
            'train_end_time' => time()
        ]);
        $this->success('班级课程已完成');
    }

    /**
     * 学员详情
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function student_detail(){
        $param=input('param.');
        if(isset($param['id']) && !empty($param['id'])){
            $ress= (new C())
                ->with('profession,professionTop')
                ->where('id',$param['id'])
                ->find();
        }else{
            $this->error('页面出错了！');
        }
        $profession_fields = explode(',',$ress['profession_fields']);
        $field_ids = (new \app\backend\model\ProfessionFields())
            ->where('id','in',$ress['profession']['field_ids'])
            ->select();
        foreach ($field_ids as $k => $v){
            if (in_array($v['id'],$profession_fields)){
                $field_ids[$k]['checked'] = true;
            }
        }
        // 缴费记录
        $pay_log = (new PayLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 培训记录
        $grade_student = (new GradeStudent())
            ->with('grade,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 考试记录
        $exam_student = (new ExamStudent())
            ->with('exam,payStudent')
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 退费记录
        $refund_log = (new RefundLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        // 发票记录
        $invoice_log = (new InvoiceLog())
            ->where([
                'pay_student_id' => $ress['id']
            ])
            ->select();
        $this->assign([
            'pay_log' => $pay_log,
            'grade_student' => $grade_student,
            'exam_student' => $exam_student,
            'refund_log' => $refund_log,
            'invoice_log' => $invoice_log,
        ]);
        $href = url($this->request->param('refund')) . '?id='.$this->request->param('grade_id');
        $data=['ress'=>$ress, 'param'=>$param,'refund' => $href];
        $this->assign('data',$data);
        $this->assign('field_ids',$field_ids);
        return  $this->fetch();
    }

    /**
     * 修改学员真实状态
     * @throws DbException
     */
    public function chang_status(){
        $id = $this->request->param('id');
        $grade_student = GradeStudent::get($id);
        (new C())->where('id',$grade_student['pay_student_id'])->update([
            'status' => 4,
            'offline_status' => 1,
            'ol_status' => 1
        ]);
        $grade_student->save([
            'status' => 1
        ]);
        $this->success('此学员培训已结束，请安排考试');
    }

    /**
     * 修改学员培训状态
     * @throws DbException
     */
    public function chang_grade_status(){
        $id = $this->request->param('id');
        $grade_student = GradeStudent::get($id);
        $grade = G::get($grade_student['grade_id']);
        if ($grade['train_site'] == 1){
            $update_data = [
                'ol_status' => 1
            ];
            $str = '线上';
        }else{
            $update_data = [
                'offline_status' => 1
            ];
            $str = '线下';
        }
        $grade_student->save([
           'status' => 1
        ]);
        (new C())->where('id',$grade_student['pay_student_id'])->update($update_data);

        $this->success('此学员'.$str.'培训已结束');
    }

    /**
     * 异常报备
     * @return mixed
     * @throws DbException
     */
    public function abnormal(){
        if ($this->request->isPost()){
            $param = $this->request->param();
            $grade = G::get($param['grade_id']);
            $check_data = [
                'grade_id' => $grade['id'],
                'teacher_id' => $grade['teacher_id'],
                'student_id' => $param['id'],
                'profession_id' => $grade['profession_id'],
                'anomalous_cause' => $param['anomalous_cause'],
                'admin_id' => $this->ausess()['auid']
            ];
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $check_data['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $check_data['campus_id'] = 1;
            }
            (new \app\backend\model\GradeCheck())->allowField(true)->save($check_data);
            $this->success('异常报备成功');
        }
        $this->assign([
            'id' => $this->request->param('id'),
            'grade_id' => $this->request->param('grade_id'),
        ]);
        return $this->fetch();
    }

    /**
     * @param $data
     * @return mixed|array
     */
    public function before_add($data){
        // 培训时间
        $data['train_action_time'] = !is_numeric($data['train_action_time']) ? strtotime($data['train_action_time']) : $data['train_action_time'];
        if (empty($data['train_end_time'])){
            ajaxReturn($this->errCode('SQLError'), '培训结束时间不能为空');
        }
        if (empty($data['train_action_time'])){
            ajaxReturn($this->errCode('SQLError'), '培训开始时间不能为空');
        }
        $data['train_end_time'] = !is_numeric($data['train_end_time']) ? strtotime($data['train_end_time']) : $data['train_end_time'];
        // 培训天数
        $train_day = (int)$data['train_end_time'] - (int)$data['train_action_time'];
        $data['train_day'] = $train_day / 24 / 3600;
        // 创建人
        $data['admin_id'] = $this->ausess()['auid'];
        // 增加校区字段
        if (!empty($this->ausess()['campus_id'])){
            $data['campus_id'] = $this->ausess()['campus_id'];
        }else{
            $data['campus_id'] = 1;
        }
        return $data;
    }

    /**
     * @param $data
     */
    public function after_add($data){

    }

    /**
     * @param $data
     */
    protected function write_log($data){

    }

    /**
     * @param $data
     */
    protected function after_del($data){

    }
}
