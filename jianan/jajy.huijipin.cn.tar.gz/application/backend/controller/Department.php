<?php
namespace app\backend\controller;

use app\backend\model\AdminDepartment;
use app\backend\model\AdminUser;
use app\backend\model\AuthGroup;
use think\Exception;
use think\exception\DbException;
use think\response\View;

class Department extends Common
{
    /**
     * 首页
     * @return View
     */
    public function index(){
        return view();
    }

    /**
     * 添加
     * @return View
     */
    public function add(){
        if(request()->isAjax()){
            $param = $this->request->param();
            (new AdminDepartment())->allowField(true)->save($param);
            $this->success('添加成功');
        }
        return view();
    }

    /**
     * 修改
     * @return View
     * @throws DbException
     */
    public function edit(){
        if(request()->isAjax()){
            $param = $this->request->param();
            $model = AdminDepartment::get($param['id']);
            $model->allowField(true)->save($param);
            $this->success('修改成功');
        }
        $id=input('id');
        return view('add',[
            'department' => AdminDepartment::get($id)
        ]);
    }

    /**
     * 新闻数据的获取
     * @access public
     * @return void [json]
     * @throws DbException
     */
    public function getData(){
        $list = (new AdminDepartment())
            ->paginate($this->request->param('limit'));
        $data = $list->items();
        layuiReturn($this->errCode('OK'), '获取成功', $list->total(), $data);
    }

    /**
     * 删除数据
     * @throws Exception
     */
    public function delData(){
        $campus = AdminDepartment::get($this->request->param('id'));
        if (empty($campus)){
            $this->error('服务器错误');
        }
        $campus->delete();
        $this->success('删除成功');
    }

    /**
     * 获取部门下的角色
     * @throws DbException
     */
    public function getSelectData(){
        $id = $this->request->param('id');
        $list = AuthGroup::all([
            'department_id' => ['in',$id.',7'],
            'status' => 1
        ]);
        $this->success('','',$list);
    }

    /**
     * 获取角色下可选择的上级管理员
     * @throws DbException
     */
    public function getPidData(){
        $id = $this->request->param('id');
        $campus_id = $this->request->param('campus_id');
        $group = AuthGroup::get([
            'id' => $id
        ]);
        if (empty($group['pid'])){
            $list = [
                [
                    'id' => 0,
                    'real_name' => '无'
                ]
            ];
        }else{
            $list = AdminUser::all([
                'group_id' => $group['pid'],
                'campus_id' => $campus_id
            ]);
        }

        $this->success('','',$list);
    }
}