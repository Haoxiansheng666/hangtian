<?php
namespace app\backend\controller;

use app\backend\model\ExamStudent;
use app\backend\model\GradeStudent;
use app\backend\model\ServiceContact;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;

class ContactStudent extends Common{

    /**
     * 参加培训学员列表
     * @return mixed
     */
    public function grade_index(){
        return $this->fetch();
    }

    /**
     * 参加培训学员数据
     * @throws DbException
     */
    public function getGradeData(){
        $where = [];
        $param = $this->request->param();
        if (isset($param['contact_status'])){
            if ($param['contact_status'] == '0'){
                $where['contact_status'] = ['in','0,3'];
            }else{
                $where['contact_status'] = ['in','1,2'];
            }
        }
        $grade_student = (new GradeStudent())
            ->with('payStudent.admin,grade.teacher')
            ->where($where)
            ->paginate($this->request->param('limit','15'))
            ->each(function ($row){
                $profession = \app\backend\model\Profession::get($row->grade->profession_id);
                $row->profession = $profession;
                return $row;
            });
        $data = $grade_student->items();
        layuiReturn($this->errCode('OK'),'',$grade_student->total(),$data);

    }

    /**
     * 参加考试学员列表
     * @return mixed
     */
    public function exam_index(){
        return $this->fetch();
    }

    /**
     * 参加考试学员数据
     * @throws DbException
     */
    public function getExamData(){
        $where = [];
        $param = $this->request->param();
        if (isset($param['contact_status'])){
            if ($param['contact_status'] == '0'){
                $where['contact_status'] = ['in','0,3'];
            }else{
                $where['contact_status'] = ['in','1,2'];
            }
        }
        $grade_student = (new ExamStudent())
            ->with('payStudent.admin,exam.teacher')
            ->where($where)
            ->paginate($this->request->param('limit','15'))
            ->each(function ($row){
                $profession = \app\backend\model\Profession::get($row->exam->profession_id);
                $row->profession = $profession;
                return $row;
            });
        $data = $grade_student->items();
        layuiReturn($this->errCode('OK'),'',$grade_student->total(),$data);

    }

    /**
     * 联系学员页面
     * @return mixed
     * @throws DbException
     * @throws DataNotFoundException
     * @throws ModelNotFoundException
     */
    public function contact(){
        $id = $this->request->param('id');
        $type = $this->request->param('type');

        // 返回上一级页面路径
        $refund = $type == 'grade' ? url('ContactStudent/grade_index') : url('ContactStudent/exam_index');
        // 班级/考试学员
        if ($type == 'grade'){
            $student = (new GradeStudent())->with('payStudent,grade');
        }else{
            $student = (new  ExamStudent())->with('payStudent,exam');
        }
        $student = $student->find(['id' => $id]);
        $where = [
            'pay_student_id' => $student['pay_student_id'],
            'type' => $type == 'grade' ? 1 : 2,
        ];
        if (!empty($student['grade'])){
            $where['grade_id'] = $student['grade_id'];
        }
        if (!empty($student['exam'])){
            $where['exam_id'] = $student['exam_id'];
        }
        // 联系记录
        $service_contact = (new ServiceContact())->with('admin')->where($where)->select();
        $this->assign([
            'id' => $id,
            'type' => $type,
            'refund' => $refund,
            'student' => $student,
            'service_contact' => $service_contact
        ]);
        cache($type . '_' . $id , true , 600);
        if ($type == 'grade'){
            return $this->fetch('grade_contact');
        }
        return $this->fetch('exam_contact');
    }

    /**
     * 其他客服正在联系此学员判断
     */
    public function contact_check(){
        $id = $this->request->param('id');
        $type = $this->request->param('type');
        $session = cache($type . '_' . $id);
        if (!empty($session)){
            $this->error('其他客服正在联系此学员');
        }
        $this->success();
    }

    /**
     * 删除去联系锁定条件
     */
    public function contact_cache_delete(){
        $id = $this->request->param('id');
        $type = $this->request->param('type');
        $session = cache($type . '_' . $id);
        if (!empty($session)){
            cache($type . '_' . $id,false,1);
            $this->success();
        }
        $this->error();
    }

    /**
     * 学员可以准时参加
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function consent(){
        $this->saveContactStatus(1);
        $this->success('学员状态已修改');
    }

    /**
     * 学员状态修改为待定
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function undetermined(){
        if ($this->request->isPost()){
            $this->saveContactStatus(3);
            $this->success('学员状态已修改');
        }
        $this->assign([
            'id' => $this->request->param('id'),
            'type' => $this->request->param('type'),
        ]);
        return $this->fetch();
    }

    /**
     * 学员状态修改为不能参加
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function refuse(){
        if ($this->request->isPost()){
            $this->saveContactStatus(2);
            $this->success('学员状态已修改');
        }
        $this->assign([
            'id' => $this->request->param('id'),
            'type' => $this->request->param('type'),
        ]);
        return $this->fetch();
    }

    /**
     * 保存学员联系状态
     * @param $status
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function saveContactStatus($status){
        $id = $this->request->param('id');
        $type = $this->request->param('type');
        if ($type == 'grade'){
            $model = (new GradeStudent())->with('payStudent,grade');
        }else{
            $model = (new ExamStudent())->with('payStudent,exam');
        }
        $student = $model->find(['id' => $id]);
        $contact_log = [
            'pay_student_id' => $student['pay_student_id'],
            'type' => !empty($student['grade']) ? 1 : 2,
            'grade_id' => !empty($student['grade']) ? $student['grade_id'] : null,
            'exam_id' => !empty($student['exam']) ? $student['exam_id'] : null,
            'contact_status' => $status,
            'contact_time' => time(),
            'contact_admin_id' => $this->ausess()['auid'],
        ];

        if ($this->request->param('feedback')){
            $contact_log['feedback'] = $this->request->param('feedback');
        }

        if ($this->request->param('remark')){
            $contact_log['remark'] = $this->request->param('remark');
        }

        // 保存客服联系学员记录
        (new ServiceContact())->allowField(true)->save($contact_log);
        // 修改班级/考试计划内学员记录
        $student->save([
            'contact_status' => $status
        ]);
    }
}