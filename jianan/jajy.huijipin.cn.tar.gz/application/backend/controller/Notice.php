<?php
namespace app\backend\controller;

use app\backend\model\AdminDepartment;
use think\Controller;
use think\exception\DbException;
use think\response\View;
use think\Session;
use think\Request;
use app\common\model\Notice as N;

class Notice extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        $department = AdminDepartment::all();
        $this->assign([
            'department' => $department,
            'contents_check' => true
        ]);
    }

    /**
     * 列表
     * @return View
     * @throws DbException
     */
    public function index(){
        $i=new N();
        $where = [];
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }
        $res=$i
            ->where($where)
            ->whereOr([
                'department_id' => 0
            ])
            ->paginate(15);
        $list=$res->toArray()['data'];
        return view('',[
           'data' => $list,
           'page' => $res->render()
        ]);
    }

    public function getData(){
        $i=new N();
        $where = [];
        if ($this->ausess()['group_id'] != 1){
            $where['department_id'] = $this->ausess()['department_id'];
        }
        $res=$i
            ->where($where)
            ->whereOr([
                'department_id' => 0
            ])
            ->paginate(15);

        layuiReturn($this->errCode('OK'), '获取成功', $res->count(), $res->items());
    }

    /**
     * 添加
     * @return bool|View
     */
    public function add(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new N();
            $this->addAction($model);
            return false;
        }

        return view('',[
            'url' => url('notice/add')
        ]);
    }

    /**
     * 修改
     * @return bool|View
     * @throws \think\Exception
     * @throws DbException
     */
    public function edit(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            $model=new N();
            $this->addAction($model);
            return false;
        }
        $id=input('id');
        $notice=N::get($id);
        return view('add',[
            'data' => $notice,
            'url' => url('notice/edit')
        ]);
    }
    public function delData(){
        if(var_export(Request::instance()->isAjax(), true)==='true'){
            (new N())->where([
                'id' => ['in',$this->request->param('id')]
            ])->delete();
            $this->success('删除成功');
        }
    }

    /**
     * 数据提交之前的操作
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return [array]
     */
    protected function before_add($data){
        if ($data['ware_id'] == 1 && !empty($data['department_id'])){
            $this->error('参数错误');
        }
        if ($data['ware_id'] == 2 && empty($data['department_id'])){
            $this->error('请选择部门');
        }
        if (empty($data['department_id'])){
            $data['department_id'] = 0;
        }
        if (!empty($this->campus_id)){
            $data['campus_id'] = $this->campus_id;
        }
        return $data;
    }
    /**
     * 数据提交之后的操作
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return []
     */
    protected function after_add($data){
    }

    /**
     * 数据提交之后写入数据库
     * @access public
     * @param  array  $data  接收的数据
     * @since dxf
     * @return []
     */
    protected function write_log($data){

    }
    /**
     * 数据删除之后的操作
     * @access public
     * @param  array  $data  数据
     * @since dxf
     * @return []
     */
    protected function after_del($data){
    }
}
