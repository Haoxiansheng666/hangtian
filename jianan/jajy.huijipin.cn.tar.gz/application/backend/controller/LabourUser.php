<?php
namespace app\backend\controller;

use app\backend\logic\LabourLogic;
use app\backend\model\AdminUser;
use app\backend\model\ExamStudent;
use app\backend\model\GradeStudent;
use app\backend\model\LabourUserWork;
use app\backend\model\ProfessionCate;
use app\backend\model\ServiceContact;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;
use think\exception\DbException;
use app\backend\model\LabourUser as L;
use think\Request;

class LabourUser extends Common{
    private $id;
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        $status = (new L)->status();
        unset($status['4']);
        $work_exp = (new L)->work_exp();
        $admin_list = AdminUser::all(['status' => 1]);
        $xz = [
            '面议',
            '3000 - 5000',
            '5000 - 8000',
            '8000 - 12000',
            '12000以上'
        ];
        $this->assign([
            'status' => $status,
            'work_exp' => $work_exp,
            'admin_list' => $admin_list,
            'xz' => $xz
        ]);
        $this->id = $this->request->param('id');
    }

    /**
     * 就业学员列表
     * @return mixed
     */
    public function index(){
        return $this->fetch();
    }

    /**
     * 就业学员数据
     * @throws DbException
     */
    public function getData(){
        $param = $this->request->param();
        $where = LabourLogic::selectParam($param,$this->ausess());
        $grade_student = (new L())
            ->with('profession,salesman')
            ->where($where)
            ->order('id DESC')
            ->paginate($this->request->param('limit','15'));
        $data = $grade_student->items();
        foreach ($data as $k => $v){
            if (!empty($v['profession']['name'])){
                $profession_top = \app\backend\model\Profession::get($v['profession']['pid']);
                $data[$k]['profession_name_text'] = $profession_top['name'] . ' - - ' . $v['profession']['name'];
            }
        }
        layuiReturn($this->errCode('OK'),'',$grade_student->total(),$data);

    }

    /**
     * 就业信息审核列表
     * @return mixed
     */
    public function audit_index(){
        return $this->fetch();
    }

    /**
     * 就业学员数据
     * @throws DbException
     */
    public function getAuditData(){
        $param = $this->request->param();
        $where = LabourLogic::selectParam($param,$this->ausess());
        $where['status'] = 0;
        $grade_student = (new L())
            ->with('profession,salesman')
            ->where($where)
            ->order('id DESC')
            ->paginate($this->request->param('limit','15'));
        $data = $grade_student->items();
        foreach ($data as $k => $v){
            if (!empty($v['profession']['name'])){
                $profession_top = \app\backend\model\Profession::get($v['profession']['pid']);
                $data[$k]['profession_name_text'] = $profession_top['name'] . ' - - ' . $v['profession']['name'];
            }
        }
        layuiReturn($this->errCode('OK'),'',$grade_student->total(),$data);

    }

    /**
     * 增加就业人员
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function add(){
        if ($this->request->isPost()){
            $param = $this->request->param();
            $admin = $this->ausess();
            // 判断角色权限是否为就业部，如果是则增加审核人和审核时间，如果不是则增加业务员，进入就业信息审核
            $param['salesman_id'] = $admin['auid'];
            if (!in_array($admin['department_id'],['7','8'])){
                $param['check_time'] = time();
                $param['check_admin_id'] = $admin['auid'];
            }
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            $model = new L();
            if (!empty($param['id'])){
                $model = $model->find(['id' => $param['id']]);
            }
            $model->allowField(true)->save($param);
            $this->success('保存成功');
        }
        $this->assign([
            'data' => [
                'cate_id' => 0,
            ]
        ]);
        return $this->fetch();
    }

    /**
     * 修改
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function edit(){
        if ($this->request->isPost()){
            $param = $this->request->param();
            $admin = $this->ausess();
            // 判断角色权限是否为就业部，如果是则增加审核人和审核时间，如果不是则增加业务员，进入就业信息审核
            $param['salesman_id'] = $admin['auid'];
            if ($admin['group_id'] === false){
                $param['check_time'] = time();
                $param['check_admin_id'] = $admin['auid'];
            }
            // 增加校区字段
            if (!empty($this->ausess()['campus_id'])){
                $param['campus_id'] = $this->ausess()['campus_id'];
            }else{
                $param['campus_id'] = 1;
            }
            $model = new L();
            if (!empty($param['id'])){
                $model = $model->find(['id' => $param['id']]);
            }
            $model->allowField(true)->save($param);
            $this->success('保存成功');
        }
        $user = (new L())->with('profession')->where('id',$this->id)->find();
        $user['cate_id'] = $user['profession']['cate_id'];
        $user['pid'] = $user['profession']['pid'];
        $this->assign([
            'data' => $user
        ]);
        return $this->fetch();
    }

    /**
     * 详情
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function detail(){
        $user = (new L())
            ->with('salesman,work,recommend.company,profession')
            ->where('id',$this->id)
            ->find();
        $this->assign([
            'user' => $user
        ]);
        return $this->fetch();
    }

    /**
     * 详情
     * @return mixed
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function audit_detail(){
        $user = (new L())
            ->with('salesman,work,recommend.company,profession')
            ->where('id',$this->id)
            ->find();
        $profession_top = \app\backend\model\Profession::get($user['profession']['pid']);
        $user['profession_name'] = $profession_top['name'] . ' - - ' . $user['profession']['name'];
        $this->assign([
            'user' => $user
        ]);
        return $this->fetch();
    }

    /**
     * 同意
     * @throws DbException
     */
    public function consent(){
        $user = L::get($this->id);
        if (empty($user)){
            $this->error('服务器错误');
        }
        $user->status = 1;
        $user->check_time = time();
        $user->check_admin_id = $this->ausess()['auid'];
        $user->save();
        $this->success('审核状态修改成功');
    }

    /**
     * 拒绝
     * @return mixed
     * @throws DbException
     */
    public function refuse(){
        if ($this->request->isPost()){
            $param = $this->request->param();
            $user = L::get($this->id);
            if (empty($user)){
                $this->error('服务器错误');
            }
            $user->status = -1;
            $user->feedback = $param['feedback'];
            $user->check_time = time();
            $user->check_admin_id = $this->ausess()['auid'];
            $user->save();
            $this->success('审核状态修改成功');
        }
        $this->assign([
            'id' => $this->id
        ]);
        return $this->fetch();
    }

    /**
     * 删除
     * @throws DbException
     */
    public function delete(){
        $user = L::get($this->id);
        $user->delete();
        $this->success('删除成功');
    }

    public function work_exp(){
        if ($this->request->isPost()){
            $param = $this->request->param();
            $work = [];
            $work_update = [];
            foreach ($param['company'] as $k => $v){
                if (!empty($v) && empty($param['exp_id'][$k])){
                    $work[] = [
                        'labour_user_id' => $this->id,
                        'action_time' => !empty($param['action_time'][$k]) ? strtotime( $param['action_time'][$k]) : time(),
                        'end_time' => !empty($param['end_time'][$k]) ? strtotime( $param['end_time'][$k]) : time(),
                        'company' => $v,
                        'remark' => !empty($param['remark'][$k]) ? $param['remark'][$k] : '',
                    ];
                }elseif(!empty($v) && !empty($param['exp_id'][$k])){
                    $work_update[] = [
                        'labour_user_id' => $this->id,
                        'action_time' => !empty($param['action_time'][$k]) ? strtotime( $param['action_time'][$k]) : time(),
                        'end_time' => !empty($param['end_time'][$k]) ? strtotime( $param['end_time'][$k]) : time(),
                        'company' => $v,
                        'remark' => !empty($param['remark'][$k]) ? $param['remark'][$k] : '',
                        'id' => $param['exp_id'][$k]
                    ];
                }
            }
            if (!empty($work_update)){
                foreach ($work_update as $k => $v){
                    (new LabourUserWork())->where('id',$v['id'])->update($v);
                }
                (new LabourUserWork())->whereNotIn('id',$param['exp_id'])->delete();
            }
            if (!empty($work)){
                (new LabourUserWork())->allowField(true)->saveAll($work);
            }
            $this->success('工作经历添加成功');
        }
        $work_list = (new LabourUserWork())
            ->where('labour_user_id',$this->id)
            ->select();
        $this->assign([
            'id' => $this->id,
            'work_list' => $work_list
        ]);
        return $this->fetch();
    }

}