<?php
namespace app\backend\controller;
use app\backend\logic\CertLogic;
use app\backend\model\PayStudent as C;
use app\backend\model\ProfessionCate;
use think\exception\DbException;
use think\Request;
use app\backend\model\AdminUser;
use app\backend\model\Grade as G;
class Cert extends Common
{
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        // 班主任
        $aulist=AdminUser::all(['group_id' => 4]);
        $this->assign('aulist',$aulist);
        // 工种分类
        $pro_cate_list= ProfessionCate::all();
        $this->assign('pro_cate_list',$pro_cate_list);
        // 状态
        $status = (new G)->getStatusArray();
        $this->assign('status_list',$status);
    }

    /**
     * 线上班级列表页面
     * @return mixed
     */
    public function index_audit(){
        return $this->fetch();
    }

    /**
     * 获取线上班级数据
     * @throws DbException
     */
    public function getAuditData(){
        $where = CertLogic::selectParam($this->request->param(),$this->ausess());
        if (!empty($this->campus_id)){
            $where['campus_id'] = $this->campus_id;
        }
        $list = (new \app\backend\model\Cert())
            ->with('payStudent.admin')
            ->where($where)
            ->paginate($this->request->param('limit'));
        $data = $list->items();
        layuiReturn($this->errCode('OK'), '获取成功', $list->count(), $data);
    }

    /**
     * 领证申请已通过
     * @throws DbException
     */
    public function consent(){
        $id = $this->request->param('id');
        $cert = \app\backend\model\Cert::get($id);
        $student = C::get($cert['pay_student_id']);
        $profession =  \app\backend\model\Profession::get($student['profession_id']);
        if ($this->request->isPost()){
            // 修改学员状态
            $student->save([
                'status' => 8
            ]);
            $cert->save([
                'status' => 1,
                'expressage_number' => $this->request->param('expressage_number'),
                'address' => $this->request->param('address')
            ]);
            $this->success('领证申请已通过');
        }
        $this->assign([
            'id' => $id,
            'cert' => $cert,
            'profession' => $profession,
            'student' => $student
        ]);
        return $this->fetch();
    }
    /**
     * 领证申请已拒绝
     * @throws DbException
     */
    public function refuse(){
        $id = $this->request->param('id');
        if ($this->request->isPost()){
            // 修改学员状态
            $cert = \app\backend\model\Cert::get($id);
            $cert->save([
                'status' => '-1'
            ]);
            $this->success('领证申请已拒绝');
        }
        $this->assign([
            'id' => $id
        ]);
        return $this->fetch();
    }

    /**
     * @param $data
     */
    public function after_add($data){

    }

    /**
     * @param $data
     */
    protected function write_log($data){

    }

    /**
     * @param $data
     */
    protected function after_del($data){

    }
}
