<?php
namespace app\backend\validate;
use think\Validate;
class Exam extends Validate
{

}