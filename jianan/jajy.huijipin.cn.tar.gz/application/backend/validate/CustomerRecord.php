<?php
namespace app\backend\validate;
use think\Validate;
class CustomerRecord extends Validate
{
    // 验证规则
    protected $rule = [
       
    ];
    
    
}