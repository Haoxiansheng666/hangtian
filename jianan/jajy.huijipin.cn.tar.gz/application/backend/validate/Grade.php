<?php
namespace app\backend\validate;
use think\Validate;
class Grade extends Validate
{

}