<?php
namespace app\backend\validate;
use think\Validate;
class Notice extends Validate
{
    
}