<?php

namespace app\backend\logic;

use app\backend\model\AdminUser;
use app\backend\model\LabourCompanyDemand;
use app\backend\model\PayStudent;
use app\backend\model\Profession;
use think\Db;
use think\Model;
use think\Request;

class LabourLogic
{
    /**
     * 客户查询的逻辑
     * @access public
     * @param array $param 条件数据
     * @param array $ausess 账号的session信息
     * @return array [array]
     * @since dxf
     */
    static public function selectParam($param, $ausess)
    {
        $where = [];
        //班级名称
        if (isset($param['name']) && !empty($param['name'])) {
            $where['name'] = array('like', "%$param[name]%");
        }
        //班主任
        if (isset($param['teacher_id']) && !empty($param['teacher_id'])) {
            $where['teacher_id'] = $param['teacher_id'];
        }
        // 业务员
        if (isset($param['admin_id']) && !empty($param['admin_id'])) {
            $where['salesman_id'] = $param['admin_id'];
        }
        // 工作经验
        if (!empty($param['work_exp'])){
            $where['work_exp'] = $param['work_exp'];
        }
        //学员状态
        if ($param['ware_id'] == 1){
            $where['status'] = ['in','0,1,2,3,5,-1'];
        }else{
            $where['status'] = ['in','4'];
        }
        if (!empty($param['status']) && $param['ware_id'] != 2){
            $where['status'] = $param['status'];
        }
        //工种
        if (!empty($param['profession_id'])) {
            $where['profession_id'] = $param['profession_id'];
        } // 一级栏目
        elseif (!empty($param['pid'])) {
            $profession_ids = (new Profession())
                ->where([
                    'pid' => $param['pid']
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        } // 工种类型
        elseif (!empty($param['cate_id'])) {
            $profession_ids = (new Profession())
                ->where([
                    'cate_id' => $param['cate_id'],
                    'pid' => 0
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        }
        return $where;
    }
    /**
     * 客户查询的逻辑
     * @access public
     * @param array $param 条件数据
     * @param array $ausess 账号的session信息
     * @return array [array]
     * @since dxf
     */
    static public function selectCompanyParam($param, $ausess)
    {
        $where = [];
        //班级名称
        if (isset($param['name']) && !empty($param['name'])) {
            $where['name'] = array('like', "%$param[name]%");
        }
        if (isset($param['contact_name']) && !empty($param['contact_name'])) {
            $where['contact_name'] = array('like', "%$param[contact_name]%");
        }
        if (isset($param['contact_mobile']) && !empty($param['contact_mobile'])) {
            $where['contact_mobile'] = array('like', "%$param[contact_mobile]%");
        }
        //班主任
        if (isset($param['teacher_id']) && !empty($param['teacher_id'])) {
            $where['salesman_id'] = $param['teacher_id'];
        }
        // 需求
        if (!empty($param['demand_id'])){
            $where['demand_id'] = $param['demand_id'];
        }
        // 用人企业
        if (!empty($param['company_id'])){
            $where['company_id'] = $param['company_id'];
        }
        //学员状态
        if (!empty($param['status'])){
            $where['status'] = $param['status'];
        }
        return $where;
    }

    /**
     * 客户查询的逻辑
     * @access public
     * @param array $param 条件数据
     * @param array $ausess 账号的session信息
     * @return array [array]
     * @since dxf
     */
    static public function selectDemandParam($param, $ausess)
    {
        $where = [];
        // 公司ID
        if (!empty($param['company_id'])){
            $where['company_id'] = $param['company_id'];
        }
        //班级名称
        if (isset($param['name']) && !empty($param['name'])) {
            $where['name'] = array('like', "%$param[name]%");
        }
        if (isset($param['mobile']) && !empty($param['mobile'])) {
            $where['mobile'] = array('like', "%$param[contact_mobile]%");
        }
        //工种
        if (!empty($param['profession_id'])) {
            $where['profession_id'] = $param['profession_id'];
        } // 一级栏目
        elseif (!empty($param['pid'])) {
            $profession_ids = (new Profession())
                ->where([
                    'pid' => $param['pid']
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        } // 工种类型
        elseif (!empty($param['cate_id'])) {
            $profession_ids = (new Profession())
                ->where([
                    'cate_id' => $param['cate_id'],
                    'pid' => 0
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        }
        return $where;
    }

    /**
     * 客户查询的逻辑
     * @access public
     * @param array $param 条件数据
     * @param array $ausess 账号的session信息
     * @return array [array]
     * @since dxf
     */
    static public function selectRecommendParam($param, $ausess)
    {
        $where = [];
        //班级名称
        if (isset($param['name']) && !empty($param['name'])) {
            $where['name'] = array('like', "%$param[name]%");
        }
        if (isset($param['mobile']) && !empty($param['mobile'])) {
            $where['mobile'] = array('like', "%$param[contact_mobile]%");
        }
        if (isset($param['work_exp']) && !empty($param['work_exp'])) {
            $where['work_exp'] = array('like', "%$param[work_exp]%");
        }
        //工种
        if (!empty($param['profession_id'])) {
            $where['profession_id'] = $param['profession_id'];
        } // 一级栏目
        elseif (!empty($param['pid'])) {
            $profession_ids = (new Profession())
                ->where([
                    'pid' => $param['pid']
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        } // 工种类型
        elseif (!empty($param['cate_id'])) {
            $profession_ids = (new Profession())
                ->where([
                    'cate_id' => $param['cate_id'],
                    'pid' => 0
                ])
                ->column('id');
            $where['profession_id'] = ['in', $profession_ids];
        }
        // 需求
        if (!empty($param['demand_id'])){
            $demand = LabourCompanyDemand::get($param['demand_id']);
            $where['profession_id'] = $demand['profession_id'];
        }
        return $where;
    }
}
 

