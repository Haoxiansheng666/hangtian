let Swiper=document.querySelectorAll('.swis>ul');
setInterval('swiper()',3000);
function swiper(){
	let mar=Swiper.offsetLeft;
}